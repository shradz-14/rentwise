import React, { useState, useEffect } from "react";
import { getUsers, getCompatibility } from "../api";
import CompatibilityReport from "./CompatibilityReport";

const UserSearch = ({ currentUser }) => {
  const [users, setUsers] = useState([]);
  const [selectedUser, setSelectedUser] = useState(null);
  const [compatibility, setCompatibility] = useState(null);

  useEffect(() => {
    const fetchUsers = async () => {
      const res = await getUsers();
      setUsers(res.data.filter(u => u.email !== currentUser)); // exclude self
    };
    fetchUsers();
  }, [currentUser]);

  const checkCompatibility = async (user) => {
    // for simplicity, assume we have both users’ preferences
    const data = {
      sleep_schedule: "Flexible",
      cleanliness: "High",
      social_style: "Balanced",
      smoking: "No",
      alcohol: "No",
      guests_allowed: "Sometimes",
      sharing_items: "Yes",
      talkativeness: "Medium",
      work_schedule: "Flexible",
      quiet_hours: "10-7",
      budget_range: "Medium",
      location: "City"
    };
    const res = await getCompatibility(data);
    setSelectedUser(user);
    setCompatibility(res.data);
  };

  return (
    <div>
      <h2>Find a Roommate</h2>
      <ul>
        {users.map(u => (
          <li key={u.id}>
            {u.name} <button onClick={()=>checkCompatibility(u)}>Check Compatibility</button>
          </li>
        ))}
      </ul>
      {selectedUser && compatibility && <CompatibilityReport user={selectedUser} score={compatibility.compatibility_probability} />}
    </div>
  );
};

export default UserSearch;
