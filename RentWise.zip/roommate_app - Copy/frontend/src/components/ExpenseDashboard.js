import React, { useState, useEffect } from "react";
import axios from "axios";

const ExpenseDashboard = ({ currentUser = {}, roommateDetails = null }) => {
  const [expenses, setExpenses] = useState([]);
  const [newExpense, setNewExpense] = useState({
    description: "",
    amount: 0,
    paidBy: currentUser.id || null,
    splitWith: currentUser.id ? [currentUser.id] : [],
    splitType: "equal",
  });
  const [customSplit, setCustomSplit] = useState(currentUser.id ? { [currentUser.id]: 100 } : {});
  const [monthlyBudget, setMonthlyBudget] = useState(10000);
  const [showAddExpense, setShowAddExpense] = useState(false);
  const [showAllExpenses, setShowAllExpenses] = useState(false);
  const [loading, setLoading] = useState(true);
  const [balance, setBalance] = useState(0);
  const [chartVersion, setChartVersion] = useState(Date.now());
  const [selectedChart, setSelectedChart] = useState(null);
  const [recommendations, setRecommendations] = useState(null);

  // NEW: Trend filter state
  const [trendView, setTrendView] = useState("monthly");

  // NEW: Budget edit state
  const [isEditingBudget, setIsEditingBudget] = useState(false);
  const [tempBudget, setTempBudget] = useState(monthlyBudget);

  // Auto-refresh chart every 20s
  useEffect(() => {
    const interval = setInterval(() => setChartVersion(Date.now()), 20000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    setChartVersion(Date.now());
  }, [expenses]);

  useEffect(() => {
    if (!currentUser || !currentUser.id) return;
    fetchExpenses();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentUser.id]);

  useEffect(() => {
    calculateBalances();
  }, [expenses, currentUser.id]);

  useEffect(() => {
    fetchRecommendations();
  }, [expenses]);

  const fetchRecommendations = async () => {
    try {
      const res = await axios.get("http://localhost:5000/api/recommendations");
      setRecommendations(res.data);
    } catch (err) {
      console.error("Error fetching recommendations:", err);
      setRecommendations(null);
    }
  };

  const fetchExpenses = async () => {
    if (!currentUser || !currentUser.id) {
      setLoading(false);
      return;
    }

    try {
      const res = await axios.get(`http://localhost:5000/api/expenses/${currentUser.id}`);
      const parsedExpenses = (res.data.expenses || []).map((exp) => ({
        ...exp,
        split_with: Array.isArray(exp.split_with)
          ? exp.split_with
          : (() => {
              try {
                return JSON.parse(exp.split_with || "[]");
              } catch (e) {
                return [];
              }
            })(),
      }));
      setExpenses(parsedExpenses);
      setLoading(false);
    } catch (err) {
      console.error("Fetch expenses error:", err);
      setExpenses([]);
      setLoading(false);
    }
  };

  const handleSplitTypeChange = (type) => {
    setNewExpense((prev) => ({
      ...prev,
      splitType: type,
      splitWith:
        type === "equal"
          ? [currentUser.id, ...(roommateDetails ? [roommateDetails.id] : [])].filter(Boolean)
          : prev.splitWith,
    }));

    if (type === "equal") {
      const people = [currentUser.id, ...(roommateDetails ? [roommateDetails.id] : [])].filter(Boolean);
      const equalPercent = people.length ? 100 / people.length : 100;
      const newSplit = {};
      people.forEach((id) => (newSplit[id] = equalPercent));
      setCustomSplit(newSplit);
      setNewExpense((prev) => ({ ...prev, splitWith: people }));
    }
  };

  const handleCustomSplitChange = (userId, value) => {
    let newVal = Number(value);
    if (isNaN(newVal) || newVal < 0) newVal = 0;
    if (newVal > 100) newVal = 100;
    setCustomSplit((prev) => ({ ...prev, [userId]: newVal }));
  };

  const isCustomSplitValid = () => {
    const total = Object.values(customSplit).reduce((a, b) => a + b, 0);
    return Math.abs(total - 100) < 0.0001;
  };

  const handleAddExpense = async () => {
    if (!newExpense.description.trim() || newExpense.amount <= 0) {
      alert("Please provide a description and valid amount.");
      return;
    }
    if (newExpense.splitType === "custom" && !isCustomSplitValid()) {
      alert("Custom split percentages must sum up to 100%.");
      return;
    }

    try {
      const splitShares =
        newExpense.splitType === "equal"
          ? newExpense.splitWith.map((id) => ({ id, share: 100 / newExpense.splitWith.length }))
          : Object.entries(customSplit).map(([id, share]) => ({ id: Number(id), share }));

      await axios.post("http://localhost:5000/api/expenses/add", {
        description: newExpense.description,
        amount: newExpense.amount,
        paidBy: newExpense.paidBy,
        splitShares,
        userId: currentUser.id,
        date: new Date().toISOString(),
      });

      setNewExpense({
        description: "",
        amount: 0,
        paidBy: currentUser.id,
        splitWith: currentUser.id ? [currentUser.id] : [],
        splitType: "equal",
      });
      setCustomSplit(currentUser.id ? { [currentUser.id]: 100 } : {});
      setShowAddExpense(false);
      await fetchExpenses();

      // Force chart refresh after adding expense
      setTimeout(() => setChartVersion(Date.now()), 1000);
    } catch (err) {
      console.error("Add expense error:", err);
      alert(err.response?.data?.error || "Failed to add expense. Please try again.");
    }
  };

  const calculateBalances = () => {
    let bal = 0;
    expenses.forEach((exp) => {
      const amountNum = Number(exp.amount || 0);
      let userShare = 0;

      if (exp.splitShares && exp.splitShares.length > 0) {
        const shareObj = exp.splitShares.find((s) => s.id === currentUser.id);
        if (shareObj) userShare = (shareObj.share / 100) * amountNum;
      } else if (exp.split_with && exp.split_with.length > 0) {
        // handle case where split_with may be strings
        const shares = exp.split_with.map((s) => Number(s));
        const per = shares.length ? amountNum / shares.length : 0;
        userShare = per;
      }

      if (exp.paid_by === currentUser.id) {
        if (!exp.paid) bal += amountNum - userShare;
      } else if ((exp.split_with && exp.split_with.includes(currentUser.id)) || (exp.splitShares && exp.splitShares.some(s => s.id === currentUser.id))) {
        if (!exp.paid) bal -= userShare;
      }
    });
    setBalance(bal);
  };

  const handlePaidExpense = async (expenseId) => {
    try {
      await axios.post(`http://localhost:5000/api/expenses/paid/${expenseId}`, {
        userId: currentUser.id,
      });
      fetchExpenses();
    } catch (err) {
      console.error("Mark as paid error:", err);
      alert("Failed to mark as paid. Try again.");
    }
  };

  // NEW: Handle budget save
  const handleSaveBudget = () => {
    if (tempBudget > 0) {
      setMonthlyBudget(tempBudget);
      setIsEditingBudget(false);
    } else {
      alert("Please enter a valid budget amount.");
    }
  };

  // NEW: Get trend chart filename based on selected view
  const getTrendChartSrc = () => {
    switch (trendView) {
      case "daily":
        return "line_expense_daily.png";
      case "weekly":
        return "line_expense_weekly.png";
      case "monthly":
      default:
        return "line_expense.png";
    }
  };

  const totalExpenses = expenses.reduce((sum, exp) => sum + Number(exp.amount || 0), 0);
  const percentUsed = monthlyBudget ? Math.min((totalExpenses / monthlyBudget) * 100, 100) : 0;

  // UPDATED: Dynamic chart list with trend filter
  const charts = [
    { src: "bar_expense.png", title: "Category Breakdown", description: "Total spending by category" },
    { src: "pie_expense.png", title: "Expense Distribution", description: "Percentage split across categories" },
    { src: getTrendChartSrc(), title: "Spending Trend", description: `${trendView.charAt(0).toUpperCase() + trendView.slice(1)} spending patterns`, isTrend: true },
    { src: "roommate_contrib.png", title: "Roommate Contributions", description: "Who paid what" },
  ];

  if (loading) {
    return <div style={{ padding: "20px", textAlign: "center" }}>Loading expenses...</div>;
  }

  return (
    <div style={{ fontFamily: "Arial, sans-serif", padding: "20px", backgroundColor: "#f9fafb", minHeight: "100vh" }}>
      {/* Header */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "30px" }}>
        <div>
          <h2 style={{ fontSize: "28px", fontWeight: "bold", margin: 0, color: "#1f2937" }}>💸 Expense Dashboard</h2>
          <p style={{ color: "#6b7280", margin: "5px 0 0 0", fontSize: "14px" }}>Track and manage shared expenses</p>
        </div>
        <div style={{ display: "flex", gap: "10px" }}>
          <button onClick={() => setShowAddExpense(!showAddExpense)} style={buttonStyle("#4F90FF")}>
            + Add Expense
          </button>
          <button onClick={() => setShowAllExpenses(true)} style={buttonStyle("#10b981")}>
            View All Expenses
          </button>
        </div>
      </div>

      {/* Add Expense Form */}
      {showAddExpense && (
        <div style={{ backgroundColor: "white", padding: "25px", borderRadius: "12px", marginBottom: "25px", boxShadow: "0 1px 3px rgba(0,0,0,0.1)" }}>
          <h3 style={{ marginBottom: "20px", color: "#1f2937" }}>Add New Expense</h3>
          <div style={{ marginBottom: "15px" }}>
            <label style={labelStyle}>Description</label>
            <input
              type="text"
              value={newExpense.description}
              onChange={(e) => setNewExpense({ ...newExpense, description: e.target.value })}
              placeholder="What did you buy?"
              style={inputStyle}
            />
          </div>
          <div style={{ marginBottom: "15px" }}>
            <label style={labelStyle}>Amount (₹)</label>
            <input
              type="number"
              value={newExpense.amount || ""}
              onChange={(e) => setNewExpense({ ...newExpense, amount: parseFloat(e.target.value) || 0 })}
              placeholder="0.00"
              min="0"
              style={inputStyle}
            />
          </div>
          <div style={{ marginBottom: "15px" }}>
            <label style={labelStyle}>Paid By</label>
            <select value={newExpense.paidBy || ""} onChange={(e) => setNewExpense({ ...newExpense, paidBy: Number(e.target.value) })} style={inputStyle}>
              {currentUser?.id && <option value={currentUser.id}>{currentUser.name} (You)</option>}
              {roommateDetails && <option value={roommateDetails.id}>{roommateDetails.name} (Roommate)</option>}
            </select>
          </div>
          <div style={{ marginBottom: "15px" }}>
            <label style={labelStyle}>Split Expense</label>
            <div>
              <label style={{ marginRight: 20 }}>
                <input type="radio" checked={newExpense.splitType === "equal"} onChange={() => handleSplitTypeChange("equal")} /> Equal
              </label>
              <label>
                <input type="radio" checked={newExpense.splitType === "custom"} onChange={() => handleSplitTypeChange("custom")} /> Custom
              </label>
            </div>
          </div>
          {newExpense.splitType === "custom" &&
            (roommateDetails ? [currentUser, roommateDetails] : [currentUser]).map((user) => (
              <div key={user.id} style={{ marginBottom: "10px" }}>
                <label style={labelStyle}>{user.name} (%)</label>
                <input
                  type="number"
                  min="0"
                  max="100"
                  value={customSplit[user.id] || 0}
                  onChange={(e) => handleCustomSplitChange(user.id, e.target.value)}
                  style={{ ...inputStyle, width: "100px" }}
                />
              </div>
            ))}
          <button onClick={handleAddExpense} style={{ ...buttonStyle("#10b981"), width: "100%", marginTop: "10px" }}>
            Add Expense
          </button>
        </div>
      )}

      {/* All Expenses Modal */}
      {showAllExpenses && (
        <Modal onClose={() => setShowAllExpenses(false)} title="All Expenses">
          {expenses.length === 0 ? (
            <p style={{ textAlign: "center", color: "#6b7280", padding: "40px 0" }}>No expenses recorded yet.</p>
          ) : (
            <div style={{ display: "flex", flexDirection: "column", gap: "15px" }}>
              {expenses.map((exp) => {
                const shares = exp.split_with && exp.split_with.length ? exp.split_with.map(Number) : [];
                const userShare = shares.length ? Number(exp.amount) / shares.length : Number(exp.amount);
                const paidByName = exp.payer_name || (exp.paid_by === currentUser.id ? currentUser.name : roommateDetails?.name || "Unknown");

                return (
                  <div key={exp.id} style={{ padding: "15px", border: "1px solid #e5e7eb", borderRadius: "10px", backgroundColor: exp.paid ? "#f9fafb" : "#fff" }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                      <div style={{ flex: 1 }}>
                        <h4 style={{ margin: "0 0 8px 0", fontSize: "16px", color: "#1f2937" }}>{exp.description}</h4>
                        <p style={expenseDetailStyle}><strong>Amount:</strong> ₹{Number(exp.amount).toFixed(2)}</p>
                        <p style={expenseDetailStyle}><strong>Paid by:</strong> {paidByName}</p>
                        <p style={expenseDetailStyle}><strong>Your share:</strong> ₹{userShare.toFixed(2)}</p>
                        <p style={expenseDetailStyle}><strong>Category:</strong> {exp.category || "other"}</p>
                        <p style={expenseDetailStyle}><strong>Date:</strong> {exp.date ? new Date(exp.date).toLocaleDateString() : "-"}</p>
                        <p style={{ ...expenseDetailStyle, color: exp.paid ? "#10b981" : "#ef4444", fontWeight: "bold" }}>
                          {exp.paid ? "✓ Paid" : "⏳ Pending"}
                        </p>
                      </div>
                      {!exp.paid && exp.paid_by !== currentUser.id && ((exp.split_with && exp.split_with.map(String).includes(String(currentUser.id))) || (exp.splitShares && exp.splitShares.some(s => s.id === currentUser.id))) && (
                        <button onClick={() => handlePaidExpense(exp.id)} style={{ ...buttonStyle("#10b981"), fontSize: "12px", padding: "8px 16px" }}>
                          Mark as Paid
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </Modal>
      )}

      {/* Chart Modal */}
      {selectedChart && (
        <Modal onClose={() => setSelectedChart(null)} title={selectedChart.title}>
          <p style={{ color: "#6b7280", marginBottom: "20px", textAlign: "center" }}>{selectedChart.description}</p>
          {selectedChart.isTrend && (
            <div style={{
              backgroundColor: "#EFF6FF",
              padding: "10px 15px",
              borderRadius: "8px",
              marginBottom: "15px",
              textAlign: "center",
              color: "#4F90FF",
              fontWeight: "600",
              fontSize: "14px",
            }}>
              Showing {trendView} view
            </div>
          )}
          <img
            src={`http://localhost:5000/charts/user_${currentUser.id}/${selectedChart.src}?t=${chartVersion}`}
            alt={selectedChart.title}
            style={{ width: "100%", height: "auto", borderRadius: "8px" }}
            onError={(e) => {
              console.error("Chart load error:", e);
              e.target.src = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='400' height='300'%3E%3Crect width='400' height='300' fill='%23f3f4f6'/%3E%3Ctext x='50%25' y='50%25' text-anchor='middle' fill='%236b7280' font-size='16'%3EChart not available%3C/text%3E%3C/svg%3E";
            }}
          />
        </Modal>
      )}

      {/* UPDATED: Budget Progress with Edit Button */}
      <div style={{ padding: "20px", background: "#fff", borderRadius: "12px", boxShadow: "0 1px 3px rgba(0,0,0,0.1)", marginBottom: "25px" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "10px" }}>
          <p style={{ fontWeight: "600", margin: 0, color: "#1f2937" }}>Monthly Budget Usage</p>
          <div>
            <button
              onClick={() => {
                setIsEditingBudget(true);
                setTempBudget(monthlyBudget);
              }}
              style={{ ...buttonStyle("#8b5cf6"), padding: "6px 12px", fontSize: "12px" }}
            >
              ✏️ Edit Budget
            </button>
          </div>
        </div>

        {isEditingBudget ? (
          <div style={{ marginTop: "15px" }}>
            <label style={labelStyle}>New Monthly Budget (₹)</label>
            <div style={{ display: "flex", gap: "10px", alignItems: "center" }}>
              <input
                type="number"
                value={tempBudget}
                onChange={(e) => setTempBudget(parseFloat(e.target.value) || 0)}
                min="0"
                style={{ ...inputStyle, width: "200px" }}
              />
              <button onClick={handleSaveBudget} style={{ ...buttonStyle("#10b981"), padding: "8px 16px" }}>
                Save
              </button>
              <button onClick={() => setIsEditingBudget(false)} style={{ ...buttonStyle("#6b7280"), padding: "8px 16px" }}>
                Cancel
              </button>
            </div>
          </div>
        ) : (
          <>
            <div style={{ background: "#e5e7eb", height: "24px", borderRadius: "12px", overflow: "hidden" }}>
              <div
                style={{
                  width: `${percentUsed}%`,
                  background: percentUsed < 70 ? "#4F90FF" : percentUsed < 90 ? "#f59e0b" : "#ef4444",
                  height: "100%",
                  transition: "width 0.3s ease",
                  borderRadius: "12px",
                }}
              />
            </div>
            <p style={{ marginTop: "8px", fontSize: "14px", color: "#6b7280" }}>
              ₹{totalExpenses.toFixed(2)} of ₹{monthlyBudget.toFixed(2)} used ({percentUsed.toFixed(1)}%)
            </p>
          </>
        )}
      </div>

      {/* Summary Cards */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: "15px", marginBottom: "30px" }}>
        <SummaryCard label="Total Expenses" value={`₹${totalExpenses.toFixed(0)}`} subtext="This month" color="#4F90FF" />
        <SummaryCard label="Your Balance" value={`₹${Math.abs(balance).toFixed(0)}`} subtext={balance >= 0 ? "You are owed" : "You owe"} color={balance >= 0 ? "#10b981" : "#ef4444"} />
        <SummaryCard label="Total Transactions" value={expenses.length} subtext="Recorded expenses" color="#8b5cf6" />
      </div>

      {/* NEW: Trend View Filter */}
      <div style={{ 
        backgroundColor: "white", 
        padding: "15px 20px", 
        borderRadius: "12px", 
        marginBottom: "25px",
        boxShadow: "0 1px 3px rgba(0,0,0,0.1)",
        display: "flex",
        alignItems: "center",
        gap: "15px",
        flexWrap: "wrap"
      }}>
        <span style={{ fontWeight: "600", color: "#1f2937", fontSize: "14px" }}>📊 Trend View:</span>
        <div style={{ display: "flex", gap: "10px" }}>
          {["daily", "weekly", "monthly"].map((view) => (
            <button
              key={view}
              onClick={() => {
                setTrendView(view);
                setChartVersion(Date.now());
              }}
              style={{
                padding: "8px 16px",
                borderRadius: "8px",
                border: trendView === view ? "2px solid #4F90FF" : "1px solid #e5e7eb",
                backgroundColor: trendView === view ? "#EFF6FF" : "white",
                color: trendView === view ? "#4F90FF" : "#6b7280",
                fontWeight: trendView === view ? "600" : "400",
                cursor: "pointer",
                fontSize: "13px",
                transition: "all 0.2s",
              }}
            >
              {view.charAt(0).toUpperCase() + view.slice(1)}
            </button>
          ))}
        </div>
        <span style={{ marginLeft: "auto", fontSize: "12px", color: "#9ca3af" }}>
          Switch between daily, weekly, or monthly trends
        </span>
      </div>

      {/* Interactive Charts Grid */}
      <div style={{ marginBottom: "30px" }}>
        <h3 style={{ fontSize: "22px", fontWeight: "600", color: "#1f2937", marginBottom: "20px", textAlign: "center" }}>📊 Visual Expense Insights</h3>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", gap: "20px" }}>
          {charts.map((chart, index) => (
            <div
              key={index}
              onClick={() => setSelectedChart(chart)}
              style={{
                backgroundColor: "white",
                borderRadius: "12px",
                padding: "15px",
                boxShadow: "0 1px 3px rgba(0,0,0,0.1)",
                cursor: "pointer",
                transition: "all 0.2s ease",
                border: "2px solid transparent",
                position: "relative",
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.boxShadow = "0 4px 12px rgba(79, 144, 255, 0.2)";
                e.currentTarget.style.borderColor = "#4F90FF";
                e.currentTarget.style.transform = "translateY(-2px)";
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.boxShadow = "0 1px 3px rgba(0,0,0,0.1)";
                e.currentTarget.style.borderColor = "transparent";
                e.currentTarget.style.transform = "translateY(0)";
              }}
            >
              {chart.isTrend && (
                <div style={{
                  position: "absolute",
                  top: "10px",
                  right: "10px",
                  backgroundColor: "#4F90FF",
                  color: "white",
                  padding: "4px 8px",
                  borderRadius: "6px",
                  fontSize: "10px",
                  fontWeight: "600",
                }}>
                  {trendView.toUpperCase()}
                </div>
              )}
              <img
                src={`http://localhost:5000/charts/user_${currentUser.id}/${chart.src}?t=${chartVersion}`}
                alt={chart.title}
                style={{ width: "100%", height: "auto", borderRadius: "8px", marginBottom: "10px" }}
                onError={(e) => {
                  e.target.src = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='300' height='200'%3E%3Crect width='300' height='200' fill='%23f3f4f6'/%3E%3Ctext x='50%25' y='50%25' text-anchor='middle' fill='%236b7280' font-size='14'%3EChart loading...%3C/text%3E%3C/svg%3E";
                }}
              />
              <h4 style={{ margin: "0 0 5px 0", fontSize: "16px", color: "#1f2937", fontWeight: "600" }}>{chart.title}</h4>
              <p style={{ margin: 0, fontSize: "13px", color: "#6b7280" }}>{chart.description}</p>
              <p style={{ margin: "10px 0 0 0", fontSize: "12px", color: "#4F90FF", fontWeight: "600" }}>Click to expand →</p>
            </div>
          ))}
        </div>
      </div>

      {/* AI Recommendations */}
      {recommendations && recommendations.recommendations ? (
        <div
          style={{
            backgroundColor: "white",
            padding: "20px",
            borderRadius: "12px",
            boxShadow: "0 1px 3px rgba(0,0,0,0.1)",
            marginBottom: "30px",
          }}
        >
          <h3 style={{ fontSize: "22px", fontWeight: "600", color: "#1f2937", marginBottom: "15px" }}>
            🤖 Smart AI Recommendations
          </h3>

          <p style={{ color: "#6b7280", fontSize: "14px", marginBottom: "10px" }}>
            Based on your recent spending pattern, here's what the AI observed:
          </p>

          <ul style={{ marginLeft: "20px", color: "#374151", fontSize: "14px", lineHeight: "1.6" }}>
            {recommendations.recommendations.map((rec, i) => (
              <li key={i}>💡 {rec}</li>
            ))}
          </ul>

          <div style={{ marginTop: "15px", fontSize: "13px", color: "#6b7280" }}>
            <strong>Spending Type:</strong> {recommendations.spending_type} <br />
            <strong>Total Spent:</strong> ₹{Number(recommendations.total_spent || 0).toFixed(2)}
          </div>
        </div>
      ) : (
        <div style={{ textAlign: "center", color: "#6b7280", marginBottom: "20px" }}>
          🤖 Analyzing your expenses and generating smart insights...
        </div>
      )}

      {/* Recent Expenses */}
      <div style={{ backgroundColor: "white", padding: "20px", borderRadius: "12px", boxShadow: "0 1px 3px rgba(0,0,0,0.1)" }}>
        <h4 style={{ marginBottom: "15px", color: "#1f2937" }}>Recent Expenses</h4>
        {expenses.slice(0, 3).map((exp) => (
          <div key={exp.id} style={{ display: "flex", justifyContent: "space-between", padding: "12px 0", borderBottom: "1px solid #e5e7eb" }}>
            <div>
              <p style={{ margin: 0, fontWeight: "600", color: "#1f2937" }}>{exp.description}</p>
              <p style={{ margin: "4px 0 0 0", fontSize: "13px", color: "#6b7280" }}>
                Paid by: {exp.payer_name || (exp.paid_by === currentUser.id ? currentUser.name : roommateDetails?.name || "Unknown")}
              </p>
            </div>
            <p style={{ margin: 0, fontWeight: "600", color: "#1f2937" }}>₹{Number(exp.amount).toFixed(2)}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

// Reusable Components
const Modal = ({ onClose, title, children }) => (
  <div
    style={{
      position: "fixed",
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      backgroundColor: "rgba(0,0,0,0.6)",
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      zIndex: 1000,
      padding: "20px",
    }}
    onClick={onClose}
  >
    <div
      style={{
        backgroundColor: "white",
        padding: "30px",
        borderRadius: "16px",
        maxWidth: "1000px",
        width: "100%",
        maxHeight: "90vh",
        overflowY: "auto",
        position: "relative",
      }}
      onClick={(e) => e.stopPropagation()}
    >
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "20px" }}>
        <h3 style={{ margin: 0, color: "#1f2937", fontSize: "22px" }}>{title}</h3>
        <button onClick={onClose} style={{ ...buttonStyle("#ef4444"), padding: "8px 16px" }}>✕ Close</button>
      </div>
      {children}
    </div>
  </div>
);

const SummaryCard = ({ label, value, subtext, color }) => (
  <div style={{ backgroundColor: "white", padding: "20px", borderRadius: "12px", boxShadow: "0 1px 3px rgba(0,0,0,0.1)" }}>
    <p style={{ color: "#6b7280", fontSize: "14px", margin: "0 0 8px 0" }}>{label}</p>
    <h3 style={{ fontSize: "32px", fontWeight: "bold", margin: "0 0 5px 0", color }}>{value}</h3>
    <p style={{ fontSize: "12px", color: "#9ca3af", margin: 0 }}>{subtext}</p>
  </div>
);

// Styles
const buttonStyle = (bgColor) => ({
  backgroundColor: bgColor,
  color: "white",
  padding: "10px 20px",
  borderRadius: "8px",
  border: "none",
  fontWeight: "600",
  cursor: "pointer",
  fontSize: "14px",
  transition: "opacity 0.2s",
});

const inputStyle = {
  width: "100%",
  padding: "12px",
  borderRadius: "8px",
  border: "1px solid #d1d5db",
  fontSize: "14px",
  color: "#1f2937",
};

const labelStyle = {
  display: "block",
  marginBottom: "6px",
  fontSize: "14px",
  fontWeight: "600",
  color: "#374151",
};

const expenseDetailStyle = {
  margin: "4px 0",
  fontSize: "13px",
  color: "#4b5563",
};

export default ExpenseDashboard;
