import React, { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const Profile = () => {
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem("user"));
  const [profileData, setProfileData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const res = await axios.get(`http://localhost:5000/api/user/${user.id}`);
        setProfileData(res.data);
      } catch (err) {
        console.error("❌ Error fetching profile:", err);
      } finally {
        setLoading(false);
      }
    };
    fetchProfile();
  }, [user.id]);

  if (loading) {
    return (
      <div
        style={{
          backgroundColor: "#162850",
          color: "white",
          minHeight: "100vh",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          fontSize: "18px",
        }}
      >
        Loading Profile...
      </div>
    );
  }

  if (!profileData) {
    return (
      <div
        style={{
          backgroundColor: "#162850",
          color: "white",
          minHeight: "100vh",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          flexDirection: "column",
        }}
      >
        <p>Profile data not found.</p>
        <button
          onClick={() => navigate("/dashboard")}
          style={backButtonStyle}
        >
          ← Back to Dashboard
        </button>
      </div>
    );
  }

  const { name, username, email, preferences } = profileData;

  return (
    <div
      style={{
        minHeight: "100vh",
        backgroundColor: "#162850",
        padding: "40px 20px",
        fontFamily: "Helvetica, Arial, sans-serif",
      }}
    >
      {/* Header */}
      <div
        style={{
          backgroundColor: "white",
          borderRadius: "12px",
          padding: "20px 30px",
          maxWidth: "900px",
          margin: "0 auto",
          boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
        }}
      >
        <h2
          style={{
            fontSize: "26px",
            fontWeight: "bold",
            color: "#162850",
            marginBottom: "5px",
          }}
        >
          {name}
        </h2>
        <p style={{ color: "#555" }}>@{username}</p>
        <p style={{ color: "#777", marginBottom: "20px" }}>{email}</p>

        <button
          onClick={() => navigate("/dashboard")}
          style={{
            backgroundColor: "#4F90FF",
            color: "white",
            padding: "10px 18px",
            border: "none",
            borderRadius: "8px",
            fontWeight: "bold",
            cursor: "pointer",
          }}
        >
          ← Back to Dashboard
        </button>
      </div>

      {/* Preferences Section */}
      <div
        style={{
          marginTop: "30px",
          backgroundColor: "white",
          borderRadius: "20px",
          padding: "30px",
          maxWidth: "900px",
          margin: "30px auto",
          boxShadow: "0 4px 15px rgba(0,0,0,0.1)",
        }}
      >
        <h3
          style={{
            fontSize: "22px",
            fontWeight: "bold",
            color: "#162850",
            marginBottom: "20px",
          }}
        >
          Lifestyle Preferences
        </h3>

        {preferences ? (
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
              gap: "15px",
            }}
          >
            {Object.entries(preferences).map(([key, value]) => (
              <div
                key={key}
                style={{
                  backgroundColor: "#f7f9fc",
                  borderRadius: "12px",
                  padding: "15px",
                  boxShadow: "0 2px 6px rgba(0,0,0,0.05)",
                }}
              >
                <p
                  style={{
                    fontWeight: "bold",
                    color: "#162850",
                    textTransform: "capitalize",
                    marginBottom: "6px",
                  }}
                >
                  {key.replace(/_/g, " ")}
                </p>
                <p style={{ color: "#555" }}>{value}</p>
              </div>
            ))}
          </div>
        ) : (
          <p style={{ color: "#666" }}>
            No preferences set yet. Please update your profile.
          </p>
        )}

        <button
          onClick={() => alert("Edit feature coming soon!")}
          style={{
            marginTop: "25px",
            backgroundColor: "#4F90FF",
            color: "white",
            border: "none",
            borderRadius: "10px",
            padding: "12px 20px",
            fontWeight: "bold",
            cursor: "pointer",
          }}
        >
          ✏️ Edit Profile
        </button>
      </div>
    </div>
  );
};

// Small back button style
const backButtonStyle = {
  marginTop: "20px",
  backgroundColor: "#4F90FF",
  color: "white",
  border: "none",
  borderRadius: "10px",
  padding: "10px 18px",
  fontWeight: "bold",
  cursor: "pointer",
};

export default Profile;
