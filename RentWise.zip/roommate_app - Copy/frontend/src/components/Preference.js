import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const Preferences = () => {
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem("user"));
  const [step, setStep] = useState(1);

  const [formData, setFormData] = useState({
    sleep_schedule: "",
    cleanliness: 5,
    smoking: "",
    alcohol: "",
    guests_allowed: "",
    social_style: "",
    sharing_items: "",
    talkativeness: "",
    work_schedule: "",
    quiet_hours: "",
    budget_range: "",
    location: "",
  });

  const updateField = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleNext = () => {
    if (step < 3) setStep(step + 1);
    else handleSubmit(); // Submit on last step
  };

  const handleBack = () => {
    if (step > 1) setStep(step - 1);
  };

  const handleSubmit = async () => {
    try {
      await axios.post(`http://localhost:5000/api/preferences/${user.id}`, formData);
      alert("Preferences saved successfully!");
      navigate("/dashboard");
    } catch (err) {
      alert(err.response?.data?.error || "Error saving preferences");
    }
  };

  const isStepComplete = () => {
    switch (step) {
      case 1:
        return formData.sleep_schedule && formData.cleanliness;
      case 2:
        return formData.smoking && formData.alcohol && formData.guests_allowed && formData.social_style;
      case 3:
        return formData.sharing_items && formData.talkativeness && formData.work_schedule && formData.quiet_hours && formData.budget_range && formData.location;
      default:
        return false;
    }
  };

  return (
    <div style={{ fontFamily: "Helvetica, Arial, sans-serif", minHeight: "94vh", backgroundColor: "#162850", padding: "20px" }}>
      <header style={{ display: "flex", alignItems: "center", backgroundColor: "#fff", padding: "10px 20px", borderRadius: "10px", marginBottom: "20px", justifyContent: "space-between" }}>
        <h2>Set My Preferences</h2>
        <button onClick={() => { localStorage.removeItem("user"); navigate("/login"); }} style={{ padding: "5px 10px", borderRadius: "5px", backgroundColor: "#f44336", color: "white", cursor: "pointer" }}>Logout</button>
      </header>

      <main style={{ backgroundColor: "white", padding: "30px", borderRadius: "20px", maxWidth: "800px", margin: "0 auto" }}>
        <p>Step {step} of 3</p>
        <div style={{ marginBottom: "20px" }}>
          {/* Step 1 */}
          {step === 1 && (
            <div>
              <label>Sleep Schedule:</label>
              <select value={formData.sleep_schedule} onChange={e => updateField("sleep_schedule", e.target.value)} style={{ width: "100%", padding: "10px", marginBottom: "10px" }}>
                <option value="">Select</option>
                <option value="early-bird">Early Bird (Before 7 AM)</option>
                <option value="normal">Normal (7 AM - 10 AM)</option>
                <option value="night-owl">Night Owl (After 10 AM)</option>
              </select>

              <label>Cleanliness: {formData.cleanliness}/10</label>
              <input type="range" min="1" max="10" value={formData.cleanliness} onChange={e => updateField("cleanliness", parseInt(e.target.value))} style={{ width: "100%" }} />
            </div>
          )}

          {/* Step 2 */}
          {step === 2 && (
            <div>
              <label>Smoking:</label>
              <select value={formData.smoking} onChange={e => updateField("smoking", e.target.value)} style={{ width: "100%", padding: "10px", marginBottom: "10px" }}>
                <option value="">Select</option>
                <option value="never">Never</option>
                <option value="occasionally">Occasionally</option>
                <option value="regularly">Regularly</option>
              </select>

              <label>Alcohol:</label>
              <select value={formData.alcohol} onChange={e => updateField("alcohol", e.target.value)} style={{ width: "100%", padding: "10px", marginBottom: "10px" }}>
                <option value="">Select</option>
                <option value="never">Never</option>
                <option value="rarely">Rarely</option>
                <option value="socially">Socially</option>
                <option value="regularly">Regularly</option>
              </select>

              <label>Guests Allowed:</label>
              <select value={formData.guests_allowed} onChange={e => updateField("guests_allowed", e.target.value)} style={{ width: "100%", padding: "10px", marginBottom: "10px" }}>
                <option value="">Select</option>
                <option value="never">Never</option>
                <option value="sometimes">Sometimes</option>
                <option value="often">Often</option>
              </select>

              <label>Social Style:</label>
              <select value={formData.social_style} onChange={e => updateField("social_style", e.target.value)} style={{ width: "100%", padding: "10px" }}>
                <option value="">Select</option>
                <option value="introverted">Introverted</option>
                <option value="ambivert">Ambivert</option>
                <option value="extroverted">Extroverted</option>
              </select>
            </div>
          )}

          {/* Step 3 */}
          {step === 3 && (
            <div>
              <label>Sharing Items:</label>
              <select value={formData.sharing_items} onChange={e => updateField("sharing_items", e.target.value)} style={{ width: "100%", padding: "10px", marginBottom: "10px" }}>
                <option value="">Select</option>
                <option value="yes">Yes</option>
                <option value="no">No</option>
              </select>

              <label>Talkativeness:</label>
              <select value={formData.talkativeness} onChange={e => updateField("talkativeness", e.target.value)} style={{ width: "100%", padding: "10px", marginBottom: "10px" }}>
                <option value="">Select</option>
                <option value="low">Low</option>
                <option value="medium">Medium</option>
                <option value="high">High</option>
              </select>

              <label>Work Schedule:</label>
              <input type="text" value={formData.work_schedule} onChange={e => updateField("work_schedule", e.target.value)} placeholder="e.g., 9 AM - 5 PM" style={{ width: "100%", padding: "10px", marginBottom: "10px" }} />

              <label>Quiet Hours:</label>
              <input type="text" value={formData.quiet_hours} onChange={e => updateField("quiet_hours", e.target.value)} placeholder="e.g., 10 PM - 7 AM" style={{ width: "100%", padding: "10px", marginBottom: "10px" }} />

              <label>Budget Range:</label>
              <select value={formData.budget_range} onChange={e => updateField("budget_range", e.target.value)} style={{ width: "100%", padding: "10px", marginBottom: "10px" }}>
                <option value="">Select</option>
                <option value="3000-5000">₹3,000 - ₹5,000</option>
                <option value="5000-8000">₹5,000 - ₹8,000</option>
                <option value="8000-12000">₹8,000 - ₹12,000</option>
                <option value="12000-15000">₹12,000 - ₹15,000</option>
                <option value="15000+">₹15,000+</option>
              </select>

              <label>Location:</label>
              <input type="text" value={formData.location} onChange={e => updateField("location", e.target.value)} placeholder="e.g., Hauz Khas" style={{ width: "100%", padding: "10px" }} />
            </div>
          )}
        </div>

        {/* Navigation Buttons */}
        <div style={{ display: "flex", gap: "10px" }}>
          {step > 1 && <button onClick={handleBack} style={{ flex: 1, padding: "10px", borderRadius: "10px" }}>Back</button>}
          <button onClick={handleNext} disabled={!isStepComplete()} style={{ flex: 1, padding: "10px", borderRadius: "10px", backgroundColor: "#4F90FF", color: "white" }}>
            {step === 3 ? "Submit" : "Next"}
          </button>
        </div>
      </main>
    </div>
  );
};

export default Preferences;
