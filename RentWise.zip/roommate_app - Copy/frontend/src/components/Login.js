import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import logo from "../assets/image-bg.png";

const Login = () => {
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [notification, setNotification] = useState(null);

  const showNotification = (message, type = "error") => {
    setNotification({ message, type });
    setTimeout(() => setNotification(null), 3000);
  };

  const handleLogin = async () => {
    try {
      const res = await axios.post("http://localhost:5000/api/login", {
        username,
        password,
      });
      localStorage.setItem("user", JSON.stringify(res.data.user));

      const prefRes = await axios.get(
        `http://localhost:5000/api/preferences/${res.data.user.id}`
      );
      if (prefRes.data.filled) navigate("/dashboard");
      else navigate("/welcome");
    } catch (err) {
      showNotification(err.response?.data?.error || "Login failed", "error");
    }
  };

  return (
    <>
      {notification && (
        <div
          style={{
            position: "fixed",
            top: "20px",
            right: "20px",
            backgroundColor:
              notification.type === "error" ? "#FF6B6B" : "#4F90FF",
            color: "white",
            padding: "15px 25px",
            borderRadius: "15px",
            boxShadow: "0 4px 15px rgba(0,0,0,0.2)",
            zIndex: 1000,
            display: "flex",
            alignItems: "center",
            gap: "10px",
            maxWidth: "350px",
          }}
        >
          <span style={{ fontSize: "20px" }}>
            {notification.type === "error" ? "❌" : "✅"}
          </span>
          <span style={{ fontWeight: "500" }}>{notification.message}</span>
        </div>
      )}

      <div
        style={{
          fontFamily: "Helvetica, Arial, sans-serif",
          minHeight: "94vh",
          backgroundColor: "#162850",
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <div
          style={{
            backgroundColor: "white",
            padding: "40px",
            borderRadius: "20px",
            minWidth: "300px",
            maxWidth: "400px",
            textAlign: "center",
          }}
        >
          <img
            src={logo}
            alt="Logo"
            style={{ height: "100px", marginBottom: "10px" }}
          />
          <h2>Login</h2>

          <label style={{ display: "block", marginTop: "10px" }}>Username</label>
          <input
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            style={{ width: "90%", padding: "10px", marginBottom: "10px" }}
          />

          <label style={{ display: "block", marginTop: "10px" }}>Password</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            style={{ width: "90%", padding: "10px", marginBottom: "20px" }}
          />

          <button
            onClick={handleLogin}
            style={{
              width: "100%",
              padding: "10px",
              borderRadius: "25px",
              backgroundColor: "#4F90FF",
              color: "white",
              fontWeight: "bold",
              cursor: "pointer",
            }}
          >
            Login
          </button>

          <a
            href="/signup"
            style={{
              display: "block",
              marginTop: "15px",
              color: "#4F90FF",
              textDecoration: "none",
            }}
          >
            New here? Sign Up
          </a>
        </div>

        <a
          href="/"
          style={{
            display: "block",
            marginTop: "20px",
            textAlign: "center",
            color: "white",
            fontSize: "16px",
            textDecoration: "underline",
          }}
        >
          Back to Home Page
        </a>
      </div>
    </>
  );
};

export default Login;
