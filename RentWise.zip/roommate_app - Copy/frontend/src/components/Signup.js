import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import logo from "../assets/image-bg.png";

const Signup = () => {
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [notification, setNotification] = useState(null);

  const showNotification = (message, type = "error") => {
    setNotification({ message, type });
    setTimeout(() => setNotification(null), 3000);
  };

  const handleSignup = async () => {
    try {
      await axios.post("http://localhost:5000/api/signup", {
        username,
        name,
        email,
        password,
      });
      showNotification("Signup successful! Redirecting to login...", "success");
      setTimeout(() => navigate("/login"), 2000);
    } catch (err) {
      showNotification(err.response?.data?.error || "Signup failed", "error");
    }
  };

  return (
    <>
      {notification && (
        <div
          style={{
            position: "fixed",
            top: "20px",
            right: "20px",
            backgroundColor:
              notification.type === "error" ? "#FF6B6B" : "#51CF66",
            color: "white",
            padding: "15px 25px",
            borderRadius: "15px",
            boxShadow: "0 4px 15px rgba(0,0,0,0.2)",
            zIndex: 1000,
            display: "flex",
            alignItems: "center",
            gap: "10px",
            maxWidth: "350px",
          }}
        >
          <span style={{ fontSize: "20px" }}>
            {notification.type === "error" ? "❌" : "✅"}
          </span>
          <span style={{ fontWeight: "500" }}>{notification.message}</span>
        </div>
      )}

      <div
        style={{
          fontFamily: "Helvetica, Arial, sans-serif",
          minHeight: "97vh",
          backgroundColor: "#162850",
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          alignItems: "center",
          marginTop: "-19px",
          marginLeft: "-19px",
          marginRight: "-19px",
          marginBottom: "-25px",
        }}
      >
        <div
          style={{
            backgroundColor: "white",
            padding: "40px",
            borderRadius: "20px",
            minWidth: "300px",
            maxWidth: "400px",
            textAlign: "center",
            marginTop: "20px",
          }}
        >
          <img
            src={logo}
            alt="Logo"
            style={{
              height: "90px",
              marginBottom: "5px",
              marginTop: "-10px",
            }}
          />
          <h2>Sign Up</h2>

          <label style={{ display: "block", marginTop: "0px" }}>Name</label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            style={{
              width: "90%",
              padding: "10px",
              marginBottom: "5px",
              height: "15px",
            }}
          />

          <label style={{ display: "block", marginTop: "5px" }}>Username</label>
          <input
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            style={{
              width: "90%",
              padding: "10px",
              marginBottom: "5px",
              height: "15px",
            }}
          />

          <label style={{ display: "block", marginTop: "5px" }}>Email</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            style={{
              width: "90%",
              padding: "10px",
              marginBottom: "5px",
              height: "15px",
            }}
          />

          <label style={{ display: "block", marginTop: "5px" }}>Password</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            style={{
              width: "90%",
              padding: "10px",
              marginBottom: "5px",
              height: "15px",
            }}
          />

          <button
            onClick={handleSignup}
            style={{
              width: "100%",
              padding: "10px",
              borderRadius: "25px",
              backgroundColor: "#4F90FF",
              color: "white",
              fontWeight: "bold",
              cursor: "pointer",
            }}
          >
            Sign Up
          </button>

          <a
            href="/login"
            style={{
              display: "block",
              marginTop: "15px",
              color: "#4F90FF",
              textDecoration: "none",
            }}
          >
            Already have an account? Login
          </a>
        </div>

        <a
          href="/"
          style={{
            display: "block",
            marginTop: "20px",
            textAlign: "center",
            color: "white",
            fontSize: "16px",
            textDecoration: "underline",
          }}
        >
          Back to Home Page
        </a>
      </div>
    </>
  );
};

export default Signup;
