import React from "react";
import logo from "../assets/image-bg.png";

const HowItWorks = () => {
  const user = JSON.parse(localStorage.getItem("user"));
  const styles = {
    container: { fontFamily: "Helvetica, Arial, sans-serif", backgroundColor: "#162850", minHeight: "94vh" },
    header: { display: "flex", justifyContent: "space-between", alignItems: "center", padding: "0 10px", backgroundColor: "#fff", color: "#000", position: "sticky", top: 0 },
    logo: { height: "100px" },
    nav: { display: "flex", gap: "20px", fontSize: "18px" },
    navLink: { textDecoration: "none", color: "black" },
    main: { padding: "50px 20px", color: "white" },
  };

  return (
    <div style={styles.container}>
      <header style={styles.header}>
        <img src={logo} alt="Logo" style={styles.logo} />
        <nav style={styles.nav}>
          <a href="/" style={styles.navLink}>Home</a>
          <a href="/features" style={styles.navLink}>Features</a>
          {user ? <a href="/dashboard" style={styles.navLink}>Dashboard</a> : <a href="/login" style={styles.navLink}>Login</a>}
        </nav>
      </header>

      <main style={styles.main}>
        <h2>How It Works</h2>
        <p>
          1. Sign up and fill your profile.<br/>
          2. Set your lifestyle preferences.<br/>
          3. Get matched with compatible roommates.<br/>
          4. Track expenses and shared calendar.<br/>
          5. AI-powered suggestions to make your life easier.
        </p>
      </main>
    </div>
  );
};

export default HowItWorks;
