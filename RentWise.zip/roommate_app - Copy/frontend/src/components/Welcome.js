import React from "react";
import { useNavigate } from "react-router-dom";
import logo from "../assets/image-bg.png";
import undrawForms from "../assets/undraw_forms_1ciz 1.png";

const Welcome = () => {
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem("user"));

  if (!user) {
    // Redirect to login if not logged in
    navigate("/login");
    return null;
  }

  const handleLogout = () => {
    localStorage.removeItem("user");
    navigate("/login");
  };

  const handlePreferences = () => {
    navigate("/preference");
  };

  const styles = {
    container: { fontFamily: "Helvetica, Arial, sans-serif", minHeight: "94vh", backgroundColor: "#162850", padding: "20px" },
    header: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      backgroundColor: "#fff",
      padding: "10px 20px",
      borderRadius: "10px",
      marginBottom: "20px",
    },
    logo: { height: "60px" },
    button: {
      backgroundColor: "#4F90FF",
      color: "white",
      padding: "8px 20px",
      borderRadius: "25px",
      border: "none",
      cursor: "pointer",
      fontWeight: "bold",
    },
    main: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "flex-start",
      backgroundColor: "white",
      padding: "30px",
      borderRadius: "20px",
      maxWidth: "1000px",
      margin: "0 auto",
      gap: "20px",
      flexWrap: "wrap",
    },
    textContainer: { maxWidth: "500px" },
    heroTitle: { fontSize: "2rem", marginBottom: "15px", color: "#162850" },
    heroText: { fontSize: "1.1rem", lineHeight: "1.6", marginBottom: "15px", color: "#162850" },
    setPrefButton: {
      backgroundColor: "#4F90FF",
      color: "white",
      padding: "12px 25px",
      borderRadius: "25px",
      border: "none",
      cursor: "pointer",
      fontWeight: "bold",
      fontSize: "1rem",
      marginTop: "10px",
    },
    image: { width: "300px", maxWidth: "100%", objectFit: "contain" },
  };

  return (
    <div style={styles.container}>
      <header style={styles.header}>
        <img src={logo} alt="Logo" style={styles.logo} />
        <button style={styles.button} onClick={handleLogout}>Logout</button>
      </header>

      <main style={styles.main}>
        <div style={styles.textContainer}>
          <h1 style={styles.heroTitle}>Welcome, {user.name} 👋</h1>
          <p style={styles.heroText}>🎯 Step 1: Add Your Preferences</p>
          <p style={styles.heroText}>
            Help us understand your lifestyle and habits.
          </p>
          <button style={styles.setPrefButton} onClick={handlePreferences}>
            Set My Preferences
          </button>
          <p style={styles.heroText}>
            🕵️‍♀️ We’ll use these to calculate your match score using our ML model.
          </p>
        </div>
        <img src={undrawForms} alt="Forms Illustration" style={styles.image} />
      </main>
    </div>
  );
};

export default Welcome;
