// src/components/Header.js
import React from "react";
import { Link } from "react-router-dom";

const Header = ({ showLogin, showSignup }) => {
  const styles = {
    header: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      padding: "10px 40px",
      backgroundColor: "#fff",
      color: "#000",
      fontFamily: "Helvetica, Arial, sans-serif",
      position: "sticky",
      top: 0,
      zIndex: 10,
    },
    nav: { display: "flex", gap: "30px", fontSize: "18px" },
    button: {
      backgroundColor: "#4F90FF",
      color: "white",
      padding: "8px 25px",
      borderRadius: "20px",
      textDecoration: "none",
      fontWeight: "bold",
    },
    link: { textDecoration: "none", color: "black" },
  };

  return (
    <header style={styles.header}>
      <div>
        <h2 style={{ margin: 0 }}>RentWise</h2>
      </div>
      <nav style={styles.nav}>
        <Link to="/" style={styles.link}>Home</Link>
        <Link to="/features" style={styles.link}>Features</Link>
        <Link to="/how-it-works" style={styles.link}>How It Works</Link>
        {showLogin && <Link to="/login" style={styles.button}>Login</Link>}
        {showSignup && <Link to="/signup" style={styles.button}>Sign Up</Link>}
      </nav>
    </header>
  );
};

export default Header;
