import React, { useState, useEffect } from "react";
import axios from "axios";

const Calendar = ({ currentUser }) => {
  const [events, setEvents] = useState([]);
  const [showAddEvent, setShowAddEvent] = useState(false);
  const [newEvent, setNewEvent] = useState({
    event_name: "",
    due_date: "",
    reminder_type: "none",
  });
  const [loading, setLoading] = useState(true);
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth());
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  const [selectedEvent, setSelectedEvent] = useState(null);

  // Fetch events for current user
  useEffect(() => {
    if (currentUser?.id) {
      fetchEvents();
    }
  }, [currentUser]);

  const fetchEvents = async () => {
    try {
      const res = await axios.get(`http://localhost:5000/api/calendar/${currentUser.id}`);
      setEvents(res.data || []);
      setLoading(false);
    } catch (err) {
      console.error("Error fetching events:", err);
      setEvents([]);
      setLoading(false);
    }
  };

  // Add event and trigger email
  const handleAddEvent = async () => {
    if (!newEvent.event_name.trim() || !newEvent.due_date) {
      alert("Please provide event name and due date.");
      return;
    }

    try {
      const response = await axios.post("http://localhost:5000/api/calendar/add", {
        user_id: currentUser.id,
        event_name: newEvent.event_name,
        due_date: newEvent.due_date,
        reminder_type: newEvent.reminder_type,
        email: currentUser.email, // used for email reminder
      });

      // Trigger backend email API
      await axios.post("http://localhost:5000/api/calendar/send-reminder", {
        user_id: currentUser.id,
        event_name: newEvent.event_name,
        due_date: newEvent.due_date,
        reminder_type: newEvent.reminder_type,
        email: currentUser.email,
      });

      setNewEvent({ event_name: "", due_date: "", reminder_type: "none" });
      setShowAddEvent(false);
      fetchEvents();
      alert("✅ Event added successfully! Email reminder scheduled.");
    } catch (err) {
      console.error("Error adding event:", err);
      alert("Failed to add event. Please try again.");
    }
  };

  const handleDeleteEvent = async (eventId) => {
    if (!window.confirm("Are you sure you want to delete this event?")) return;

    try {
      await axios.delete(`http://localhost:5000/api/calendar/delete/${eventId}`);
      fetchEvents();
      setSelectedEvent(null);
      alert("🗑️ Event deleted successfully!");
    } catch (err) {
      console.error("Error deleting event:", err);
      alert("Failed to delete event. Please try again.");
    }
  };

  // Calendar logic
  const daysInMonth = (month, year) => new Date(year, month + 1, 0).getDate();
  const firstDayOfMonth = (month, year) => new Date(year, month, 1).getDay();

  const generateCalendarDays = () => {
    const days = [];
    const totalDays = daysInMonth(selectedMonth, selectedYear);
    const firstDay = firstDayOfMonth(selectedMonth, selectedYear);
    for (let i = 0; i < firstDay; i++) days.push(null);
    for (let day = 1; day <= totalDays; day++) days.push(day);
    return days;
  };

  const getEventsForDay = (day) => {
    if (!day) return [];
    const dateStr = `${selectedYear}-${String(selectedMonth + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
    return events.filter((event) => event.due_date?.startsWith(dateStr));
  };

  const changeMonth = (direction) => {
    let newMonth = selectedMonth + direction;
    let newYear = selectedYear;
    if (newMonth > 11) {
      newMonth = 0;
      newYear++;
    } else if (newMonth < 0) {
      newMonth = 11;
      newYear--;
    }
    setSelectedMonth(newMonth);
    setSelectedYear(newYear);
  };

  const isToday = (day) => {
    const today = new Date();
    return (
      day === today.getDate() &&
      selectedMonth === today.getMonth() &&
      selectedYear === today.getFullYear()
    );
  };

  const isPastDate = (day) => {
    if (!day) return false;
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const checkDate = new Date(selectedYear, selectedMonth, day);
    return checkDate < today;
  };

  const calendarDays = generateCalendarDays();
  const monthNames = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];

  const upcomingEvents = events
    .filter((event) => new Date(event.due_date) >= new Date())
    .sort((a, b) => new Date(a.due_date) - new Date(b.due_date))
    .slice(0, 5);

  if (loading) return <div style={{ padding: "20px", textAlign: "center" }}>Loading calendar...</div>;

  return (
    <div style={{ fontFamily: "Arial, sans-serif", padding: "20px", backgroundColor: "#f9fafb", minHeight: "100vh" }}>
      {/* Header */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "30px" }}>
        <div>
          <h2 style={{ fontSize: "28px", fontWeight: "bold", margin: 0, color: "#1f2937" }}>📅 Calendar & Events</h2>
          <p style={{ color: "#6b7280", margin: "5px 0 0 0", fontSize: "14px" }}>
            Schedule events and get automatic email reminders
          </p>
        </div>
        <button onClick={() => setShowAddEvent(!showAddEvent)} style={buttonStyle("#10b981")}>
          + Add Event
        </button>
      </div>

      {/* Add Event Form */}
      {showAddEvent && (
        <div style={formBox}>
          <h3 style={{ marginBottom: "20px", color: "#1f2937" }}>Create New Event</h3>

          <div style={{ marginBottom: "15px" }}>
            <label style={labelStyle}>Event Name</label>
            <input
              type="text"
              value={newEvent.event_name}
              onChange={(e) => setNewEvent({ ...newEvent, event_name: e.target.value })}
              placeholder="e.g., Pay Rent, Birthday Party"
              style={inputStyle}
            />
          </div>

          <div style={{ marginBottom: "15px" }}>
            <label style={labelStyle}>Due Date</label>
            <input
              type="date"
              value={newEvent.due_date}
              onChange={(e) => setNewEvent({ ...newEvent, due_date: e.target.value })}
              style={inputStyle}
              min={new Date().toISOString().split("T")[0]}
            />
          </div>

          <div style={{ marginBottom: "15px" }}>
            <label style={labelStyle}>Email Reminder</label>
            <select
              value={newEvent.reminder_type}
              onChange={(e) => setNewEvent({ ...newEvent, reminder_type: e.target.value })}
              style={inputStyle}
            >
              <option value="none">No Reminder</option>
              <option value="same_day">Same Day (9 AM)</option>
              <option value="one_day_before">1 Day Before</option>
              <option value="two_days_before">2 Days Before</option>
              <option value="one_week_before">1 Week Before</option>
            </select>
          </div>

          <div style={{ display: "flex", gap: "10px" }}>
            <button onClick={handleAddEvent} style={{ ...buttonStyle("#10b981"), flex: 1 }}>
              Add Event
            </button>
            <button
              onClick={() => {
                setShowAddEvent(false);
                setNewEvent({ event_name: "", due_date: "", reminder_type: "none" });
              }}
              style={{ ...buttonStyle("#6b7280"), flex: 1 }}
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Calendar + Sidebar */}
      <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: "20px" }}>
        {/* Calendar Grid */}
        <CalendarGrid
          calendarDays={calendarDays}
          monthNames={monthNames}
          selectedMonth={selectedMonth}
          selectedYear={selectedYear}
          changeMonth={changeMonth}
          getEventsForDay={getEventsForDay}
          isToday={isToday}
          isPastDate={isPastDate}
          setSelectedEvent={setSelectedEvent}
        />

        {/* Upcoming Events */}
        <UpcomingEvents upcomingEvents={upcomingEvents} setSelectedEvent={setSelectedEvent} />
      </div>

      {selectedEvent && (
        <Modal onClose={() => setSelectedEvent(null)} title="Event Details">
          <div>
            <h3 style={{ fontSize: "22px", color: "#1f2937" }}>{selectedEvent.event_name}</h3>
            <p><strong>📅 Due Date:</strong> {new Date(selectedEvent.due_date).toDateString()}</p>
            <p><strong>🔔 Reminder:</strong> {selectedEvent.reminder_type.replace(/_/g, " ")}</p>
            <p><strong>📧 Email:</strong> {currentUser.email}</p>
            <button
              onClick={() => handleDeleteEvent(selectedEvent.id)}
              style={{ ...buttonStyle("#ef4444"), width: "100%", marginTop: "20px" }}
            >
              🗑️ Delete Event
            </button>
          </div>
        </Modal>
      )}
    </div>
  );
};

// Reusable Components
const CalendarGrid = ({ calendarDays, monthNames, selectedMonth, selectedYear, changeMonth, getEventsForDay, isToday, isPastDate, setSelectedEvent }) => (
  <div style={boxStyle}>
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "20px" }}>
      <button onClick={() => changeMonth(-1)} style={buttonStyle("#4F90FF")}>← Prev</button>
      <h3 style={{ fontSize: "20px", fontWeight: "600" }}>{monthNames[selectedMonth]} {selectedYear}</h3>
      <button onClick={() => changeMonth(1)} style={buttonStyle("#4F90FF")}>Next →</button>
    </div>
    <div style={{ display: "grid", gridTemplateColumns: "repeat(7, 1fr)", gap: "5px" }}>
      {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((d) => (
        <div key={d} style={{ textAlign: "center", fontWeight: "600", color: "#6b7280" }}>{d}</div>
      ))}
      {calendarDays.map((day, index) => {
        const dayEvents = getEventsForDay(day);
        const hasEvents = dayEvents.length > 0;
        return (
          <div
            key={index}
            onClick={() => hasEvents && setSelectedEvent(dayEvents[0])}
            style={{
              minHeight: "80px",
              border: "1px solid #e5e7eb",
              borderRadius: "8px",
              backgroundColor: isToday(day) ? "#ecfdf5" : isPastDate(day) ? "#f9fafb" : "white",
              padding: "8px",
              cursor: hasEvents ? "pointer" : "default",
            }}
          >
            {day && <div style={{ fontWeight: "600", color: isToday(day) ? "#10b981" : "#1f2937" }}>{day}</div>}
            {hasEvents && (
              <div style={{ marginTop: "4px", backgroundColor: "#4F90FF", color: "white", borderRadius: "4px", padding: "2px 4px", fontSize: "10px" }}>
                {dayEvents[0].event_name}
              </div>
            )}
          </div>
        );
      })}
    </div>
  </div>
);

const UpcomingEvents = ({ upcomingEvents, setSelectedEvent }) => (
  <div style={boxStyle}>
    <h4 style={{ fontSize: "18px", fontWeight: "600", color: "#1f2937", marginBottom: "15px" }}>📋 Upcoming Events</h4>
    {upcomingEvents.length === 0 ? (
      <p style={{ color: "#6b7280", textAlign: "center" }}>No upcoming events</p>
    ) : (
      upcomingEvents.map((event) => (
        <div
          key={event.id}
          onClick={() => setSelectedEvent(event)}
          style={{
            padding: "10px",
            border: "1px solid #e5e7eb",
            borderRadius: "8px",
            marginBottom: "10px",
            cursor: "pointer",
            transition: "0.2s",
          }}
          onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = "#f0f9ff")}
          onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = "white")}
        >
          <p style={{ fontWeight: "600", color: "#1f2937", margin: 0 }}>{event.event_name}</p>
          <p style={{ fontSize: "12px", color: "#6b7280" }}>
            {new Date(event.due_date).toLocaleDateString()}
          </p>
        </div>
      ))
    )}
  </div>
);

const Modal = ({ onClose, title, children }) => (
  <div style={modalOverlay} onClick={onClose}>
    <div style={modalBox} onClick={(e) => e.stopPropagation()}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <h3 style={{ fontSize: "20px", fontWeight: "600" }}>{title}</h3>
        <button onClick={onClose} style={buttonStyle("#ef4444")}>✕</button>
      </div>
      {children}
    </div>
  </div>
);

// Styles
const buttonStyle = (bg) => ({
  backgroundColor: bg,
  color: "white",
  border: "none",
  borderRadius: "8px",
  padding: "8px 16px",
  cursor: "pointer",
  fontWeight: "600",
});

const boxStyle = {
  backgroundColor: "white",
  padding: "20px",
  borderRadius: "12px",
  boxShadow: "0 1px 3px rgba(0,0,0,0.1)",
};

const formBox = {
  backgroundColor: "white",
  padding: "25px",
  borderRadius: "12px",
  marginBottom: "25px",
  boxShadow: "0 1px 3px rgba(0,0,0,0.1)",
};

const inputStyle = {
  width: "100%",
  padding: "10px",
  borderRadius: "8px",
  border: "1px solid #d1d5db",
  fontSize: "14px",
};

const labelStyle = {
  display: "block",
  marginBottom: "6px",
  fontWeight: "600",
  color: "#374151",
};

const modalOverlay = {
  position: "fixed",
  top: 0,
  left: 0,
  right: 0,
  bottom: 0,
  backgroundColor: "rgba(0,0,0,0.5)",
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
};

const modalBox = {
  backgroundColor: "white",
  padding: "30px",
  borderRadius: "12px",
  width: "400px",
  maxHeight: "90vh",
  overflowY: "auto",
};

export default Calendar;
