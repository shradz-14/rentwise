import React from "react";

const CompatibilityReport = ({ user, score }) => {
  return (
    <div>
      <h3>Compatibility with {user.name}</h3>
      <p>Score: {Math.round(score * 100)}%</p>
      <p>Report: {score > 0.7 ? "Highly compatible" : score > 0.4 ? "Moderately compatible" : "Low compatibility"}</p>
    </div>
  );
};

export default CompatibilityReport;
