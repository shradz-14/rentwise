import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import ExpenseDashboard from "./ExpenseDashboard"; // Adjust path if needed
import Calendar from "./Calendar"; // adjust path if Calendar.js is in another folder


const Dashboard = () => {
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem("user"));

  const [roommateId, setRoommateId] = useState(null);
  const [roommateDetails, setRoommateDetails] = useState(null);
  const [usernameSearch, setUsernameSearch] = useState("");
  const [searchResult, setSearchResult] = useState(null);
  const [error, setError] = useState("");
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("Home");
  const [isAddingRoommate, setIsAddingRoommate] = useState(false);
  const [notification, setNotification] = useState(null);

  const showNotification = (message, type = "success") => {
    setNotification({ message, type });
    setTimeout(() => setNotification(null), 3000);
  };

  useEffect(() => {
    const fetchRoommate = async () => {
      try {
        const res = await axios.get(`http://localhost:5000/api/roommate/${user.id}`);
        const fetchedRoommateId = res.data.roommate_id || null;
        setRoommateId(fetchedRoommateId);

        if (fetchedRoommateId) {
          const roommateRes = await axios.get(`http://localhost:5000/api/user/${fetchedRoommateId}`);
          setRoommateDetails(roommateRes.data);
        }
      } catch (err) {
        console.error(err);
      }
    };
    fetchRoommate();
  }, [user.id]);

  const handleLogout = () => {
    localStorage.removeItem("user");
    navigate("/login");
  };

  const handleSearch = async () => {
    if (!usernameSearch.trim()) return;
    try {
      const res = await axios.get("http://localhost:5000/api/searchUser", {
        params: { username: usernameSearch, currentUserId: user.id },
      });
      setSearchResult(res.data);
      setError("");
    } catch (err) {
      setSearchResult(null);
      setError(err.response?.data?.error || "User not found");
    }
  };

  const handleSetRoommate = async (roommateId) => {
    try {
      await axios.post("http://localhost:5000/api/roommate/set", {
        userId: user.id,
        roommate_id: roommateId,
      });
      showNotification("Roommate set successfully! 🎉", "success");
      setRoommateId(roommateId);

      const roommateRes = await axios.get(`http://localhost:5000/api/user/${roommateId}`);
      setRoommateDetails(roommateRes.data);
      setSearchResult(null);
      setUsernameSearch("");
      setIsAddingRoommate(false);
    } catch (err) {
      console.error("SET ROOMMATE ERR:", err.response?.data || err);
      showNotification(err.response?.data?.error || "Failed to set roommate", "error");
    }
  };

  const handleRemoveRoommate = async () => {
    if (!window.confirm("Are you sure you want to remove your roommate?")) return;

    try {
      await axios.post("http://localhost:5000/api/roommate/remove", { userId: user.id });
      showNotification("Roommate removed successfully!", "success");
      setRoommateId(null);
      setRoommateDetails(null);
      setIsAddingRoommate(true);
      setActiveTab("Home");
    } catch (err) {
      console.error("REMOVE ROOMMATE ERR:", err);
      showNotification("Failed to remove roommate", "error");
    }
  };

  const filteredPreferences = (prefs) => {
    if (!prefs) return {};
    const exclude = ["_id", "id", "user_id"];
    return Object.fromEntries(Object.entries(prefs).filter(([k]) => !exclude.includes(k)));
  };

  return (
    <>
      {/* Notification Popup */}
      {notification && (
        <div
          style={{
            position: "fixed",
            top: "20px",
            right: "20px",
            backgroundColor: notification.type === "error" ? "#FF6B6B" : "#51CF66",
            color: "white",
            padding: "15px 25px",
            borderRadius: "15px",
            boxShadow: "0 4px 15px rgba(0,0,0,0.2)",
            zIndex: 1000,
            display: "flex",
            alignItems: "center",
            gap: "10px",
            maxWidth: "350px",
          }}
        >
          <span style={{ fontSize: "20px" }}>
            {notification.type === "error" ? "❌" : "✅"}
          </span>
          <span style={{ fontWeight: "500" }}>{notification.message}</span>
        </div>
      )}

      <div
        style={{
          fontFamily: "Inter, Arial, sans-serif",
          minHeight: "100vh",
          backgroundColor: "#162850",
          padding: "20px",
        }}
      >
        {/* Header */}
        <header
          style={{
            display: "flex",
            alignItems: "center",
            backgroundColor: "#fff",
            padding: "12px 24px",
            borderRadius: "12px",
            marginBottom: "24px",
            justifyContent: "space-between",
          }}
        >
          <h2 style={{ fontWeight: "bold", color: "#162850" }}>Dashboard</h2>

          <div style={{ position: "relative" }}>
            <span
              style={{
                marginRight: "15px",
                fontWeight: "600",
                color: "#162850",
              }}
            >
              Welcome, {user.name}
            </span>
            <button
              onClick={() => setDropdownOpen(!dropdownOpen)}
              style={{
                padding: "8px 14px",
                borderRadius: "8px",
                backgroundColor: "#4F90FF",
                color: "white",
                cursor: "pointer",
                fontWeight: "bold",
                border: "none",
              }}
            >
              Profile ▾
            </button>

            {dropdownOpen && (
              <div
                style={{
                  position: "absolute",
                  right: 0,
                  marginTop: "10px",
                  width: "160px",
                  backgroundColor: "white",
                  borderRadius: "8px",
                  boxShadow: "0 2px 10px rgba(0,0,0,0.1)",
                  overflow: "hidden",
                  zIndex: 100,
                }}
              >
                <button
                  onClick={() => {
                    setDropdownOpen(false);
                    navigate("/profile");
                  }}
                  style={dropdownItemStyle}
                >
                  View Profile
                </button>
                <button
                  onClick={handleLogout}
                  style={{ ...dropdownItemStyle, color: "red" }}
                >
                  Logout
                </button>
              </div>
            )}
          </div>
        </header>

        {/* Main Section */}
        <main
          style={{
            backgroundColor: "white",
            padding: "30px",
            borderRadius: "20px",
            maxWidth: "950px",
            margin: "0 auto",
            boxShadow: "0 3px 10px rgba(0,0,0,0.15)",
          }}
        >
          {/* Tabs - only show if roommate exists */}
          {roommateId && (
            <nav
              style={{
                display: "flex",
                gap: "15px",
                marginBottom: "20px",
                overflowX: "auto",
                whiteSpace: "nowrap",
                scrollbarWidth: "none",
              }}
            >
              {["Home", "Expenses", "Calendar"].map((tab) => (
                <button
                  key={tab}
                  onClick={() => {
                    setActiveTab(tab);
                    setIsAddingRoommate(false);
                  }}
                  style={{
                    padding: "10px 20px",
                    borderRadius: "8px",
                    backgroundColor: activeTab === tab ? "#4F90FF" : "#f7f9fc",
                    color: activeTab === tab ? "#fff" : "#162850",
                    fontWeight: "bold",
                    cursor: "pointer",
                    flexShrink: 0,
                    border: "none",
                    transition: "0.3s",
                  }}
                >
                  {tab}
                </button>
              ))}
            </nav>
          )}

          {/* Tab Content */}
          <div style={{ minHeight: "300px", transition: "0.5s ease" }}>
            {activeTab === "Home" && (
              <>
                {/* Add Roommate Mode */}
                {isAddingRoommate ? (
                  <div>
                    <h3 style={{ fontSize: "22px", fontWeight: "700", marginBottom: "12px" }}>
                      Find Your Roommate 🏡
                    </h3>
                    <p style={{ fontSize: "14px", color: "#555", marginBottom: "20px" }}>
                      Enter a username to check compatibility and connect with other students.
                    </p>

                    <div
                      style={{
                        display: "flex",
                        alignItems: "center",
                        border: "1px solid #ccc",
                        borderRadius: "8px",
                        padding: "8px 10px",
                        marginBottom: "15px",
                      }}
                    >
                      <span style={{ color: "#888" }}>@</span>
                      <input
                        type="text"
                        placeholder="username"
                        value={usernameSearch}
                        onChange={(e) => setUsernameSearch(e.target.value)}
                        style={{
                          flex: 1,
                          outline: "none",
                          border: "none",
                          marginLeft: "8px",
                          fontSize: "14px",
                        }}
                      />
                    </div>

                    <button
                      onClick={handleSearch}
                      style={{
                        width: "100%",
                        padding: "12px",
                        backgroundColor: "#4F90FF",
                        color: "white",
                        borderRadius: "10px",
                        fontWeight: "bold",
                        cursor: "pointer",
                        border: "none",
                      }}
                    >
                      Search
                    </button>

                    {error && <p style={{ color: "red", marginTop: "10px" }}>{error}</p>}

                    {searchResult && (
                      <div
                        style={{
                          backgroundColor: "#f7f9fc",
                          marginTop: "20px",
                          padding: "20px",
                          borderRadius: "12px",
                        }}
                      >
                        <h4 style={{ marginBottom: "10px" }}>@{searchResult.user.username}</h4>
                        <p>
                          Compatibility Score:{" "}
                          <span style={{ fontWeight: "bold", color: "#4F90FF" }}>
                            {searchResult.compatibilityScore}%
                          </span>
                        </p>

                        <h5 style={{ marginTop: "10px" }}>Preferences:</h5>
                        <ul style={{ listStyle: "none", padding: 0, color: "#333" }}>
                          {Object.entries(filteredPreferences(searchResult.preferences)).map(
                            ([key, value]) => (
                              <li key={key}>
                                <strong>{key.replace(/_/g, " ")}:</strong> {value}
                              </li>
                            )
                          )}
                        </ul>

                        <button
                          onClick={() => handleSetRoommate(searchResult.user.id)}
                          style={{
                            marginTop: "15px",
                            padding: "10px 20px",
                            backgroundColor: "#28a745",
                            color: "white",
                            border: "none",
                            borderRadius: "8px",
                            cursor: "pointer",
                            fontWeight: "bold",
                          }}
                        >
                          Set as Roommate
                        </button>
                      </div>
                    )}

                    <button
                      onClick={() => setIsAddingRoommate(false)}
                      style={{
                        marginTop: "15px",
                        padding: "10px 16px",
                        backgroundColor: "#f44336",
                        color: "white",
                        borderRadius: "8px",
                        fontWeight: "bold",
                        cursor: "pointer",
                        border: "none",
                      }}
                    >
                      Cancel
                    </button>
                  </div>
                ) : roommateId ? (
                  // Show roommate details
                  <div>
                    <h3 style={{ fontSize: "22px", fontWeight: "700", marginBottom: "15px" }}>
                      🏠 Your Roommate
                    </h3>

                    {roommateDetails ? (
                      <div
                        style={{
                          backgroundColor: "#f7f9fc",
                          padding: "20px",
                          borderRadius: "12px",
                          marginBottom: "20px",
                        }}
                      >
                        <div style={{ marginBottom: "15px" }}>
                          <h4 style={{ fontSize: "20px", fontWeight: "600", color: "#162850" }}>
                            {roommateDetails.name}
                          </h4>
                          <p style={{ color: "#666", fontSize: "14px" }}>
                            @{roommateDetails.username}
                          </p>
                          <p style={{ color: "#666", fontSize: "14px" }}>
                            {roommateDetails.email}
                          </p>
                        </div>

                        {roommateDetails.preferences && (
                          <div>
                            <h5 style={{ fontSize: "16px", fontWeight: "600", marginBottom: "10px" }}>
                              Preferences:
                            </h5>
                            <div
                              style={{
                                display: "grid",
                                gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
                                gap: "10px",
                              }}
                            >
                              {Object.entries(filteredPreferences(roommateDetails.preferences)).map(
                                ([key, value]) => (
                                  <div
                                    key={key}
                                    style={{
                                      backgroundColor: "white",
                                      padding: "10px",
                                      borderRadius: "8px",
                                      fontSize: "13px",
                                    }}
                                  >
                                    <strong style={{ color: "#162850" }}>
                                      {key.replace(/_/g, " ")}:
                                    </strong>{" "}
                                    <span style={{ color: "#555" }}>{value}</span>
                                  </div>
                                )
                              )}
                            </div>
                          </div>
                        )}
                      </div>
                    ) : (
                      <p>Loading roommate details...</p>
                    )}

                    {/* Buttons */}
                    <div style={{ display: "flex", gap: "10px", marginTop: "20px" }}>
                      <button
                        onClick={handleRemoveRoommate}
                        style={{
                          backgroundColor: "#f44336",
                          color: "white",
                          padding: "10px 16px",
                          borderRadius: "8px",
                          fontWeight: "bold",
                          cursor: "pointer",
                          border: "none",
                        }}
                      >
                        Remove Roommate
                      </button>

                      <button
                        onClick={() => setIsAddingRoommate(true)}
                        style={{
                          backgroundColor: "#4F90FF",
                          color: "white",
                          padding: "10px 16px",
                          borderRadius: "8px",
                          fontWeight: "bold",
                          cursor: "pointer",
                          border: "none",
                        }}
                      >
                        + Add Another Roommate
                      </button>
                    </div>
                  </div>
                ) : (
                  // No roommate yet, show find roommate UI
                  <div>
                    <h3 style={{ fontSize: "22px", fontWeight: "700", marginBottom: "12px" }}>
                      Find Your Roommate 🏡
                    </h3>
                    <p style={{ fontSize: "14px", color: "#555", marginBottom: "20px" }}>
                      Enter a username to check compatibility and connect with other students.
                    </p>

                    <div
                      style={{
                        display: "flex",
                        alignItems: "center",
                        border: "1px solid #ccc",
                        borderRadius: "8px",
                        padding: "8px 10px",
                        marginBottom: "15px",
                      }}
                    >
                      <span style={{ color: "#888" }}>@</span>
                      <input
                        type="text"
                        placeholder="username"
                        value={usernameSearch}
                        onChange={(e) => setUsernameSearch(e.target.value)}
                        style={{
                          flex: 1,
                          outline: "none",
                          border: "none",
                          marginLeft: "8px",
                          fontSize: "14px",
                        }}
                      />
                    </div>

                    <button
                      onClick={handleSearch}
                      style={{
                        width: "100%",
                        padding: "12px",
                        backgroundColor: "#4F90FF",
                        color: "white",
                        borderRadius: "10px",
                        fontWeight: "bold",
                        cursor: "pointer",
                        border: "none",
                      }}
                    >
                      Search
                    </button>

                    {error && <p style={{ color: "red", marginTop: "10px" }}>{error}</p>}

                    {searchResult && (
                      <div
                        style={{
                          backgroundColor: "#f7f9fc",
                          marginTop: "20px",
                          padding: "20px",
                          borderRadius: "12px",
                        }}
                      >
                        <h4 style={{ marginBottom: "10px" }}>@{searchResult.user.username}</h4>
                        <p>
                          Compatibility Score:{" "}
                          <span style={{ fontWeight: "bold", color: "#4F90FF" }}>
                            {searchResult.compatibilityScore}%
                          </span>
                        </p>

                        <h5 style={{ marginTop: "10px" }}>Preferences:</h5>
                        <ul style={{ listStyle: "none", padding: 0, color: "#333" }}>
                          {Object.entries(filteredPreferences(searchResult.preferences)).map(
                            ([key, value]) => (
                              <li key={key}>
                                <strong>{key.replace(/_/g, " ")}:</strong> {value}
                              </li>
                            )
                          )}
                        </ul>

                        <button
                          onClick={() => handleSetRoommate(searchResult.user.id)}
                          style={{
                            marginTop: "15px",
                            padding: "10px 20px",
                            backgroundColor: "#28a745",
                            color: "white",
                            border: "none",
                            borderRadius: "8px",
                            cursor: "pointer",
                            fontWeight: "bold",
                          }}
                        >
                          Set as Roommate
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </>
            )}

            {/* EXPENSES TAB */}
            {activeTab === "Expenses" && (
              <ExpenseDashboard currentUser={user} roommateDetails={roommateDetails} />
            )}

            {activeTab === "Calendar" && (
              <Calendar currentUser={user} roommateDetails={roommateDetails} />
            )}
          </div>
        </main>
      </div>
    </>
  );
};

const dropdownItemStyle = {
  display: "block",
  width: "100%",
  padding: "10px",
  textAlign: "left",
  border: "none",
  background: "white",
  cursor: "pointer",
  fontSize: "14px",
};

export default Dashboard;