import React from "react";
import logo from "../assets/image-bg.png";

const Features = () => {
  const user = JSON.parse(localStorage.getItem("user"));
  const styles = {
    container: { fontFamily: "Helvetica, Arial, sans-serif", backgroundColor: "#162850", minHeight: "94vh" },
    header: { display: "flex", justifyContent: "space-between", alignItems: "center", padding: "0 10px", backgroundColor: "#fff", color: "#000", position: "sticky", top: 0 },
    logo: { height: "100px" },
    nav: { display: "flex", gap: "20px", fontSize: "18px" },
    navLink: { textDecoration: "none", color: "black" },
    main: { padding: "50px 20px", display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))", gap: "20px" },
    card: { backgroundColor: "#fff", color: "#000", padding: "20px", borderRadius: "15px", minHeight: "150px" },
  };

  const featureList = [
    "User Profile & Preferences",
    "Find Friends / Compatibility Check",
    "Expense Dashboard",
    "AI-Powered Expense Analyzer",
    "Shared Calendar"
  ];

  return (
    <div style={styles.container}>
      <header style={styles.header}>
        <img src={logo} alt="Logo" style={styles.logo} />
        <nav style={styles.nav}>
          <a href="/" style={styles.navLink}>Home</a>
          <a href="/HowItWorks" style={styles.navLink}>How It Works</a>
          {user ? <a href="/dashboard" style={styles.navLink}>Dashboard</a> : <a href="/login" style={styles.navLink}>Login</a>}
        </nav>
      </header>

      <main style={styles.main}>
        {featureList.map((f, idx) => <div key={idx} style={styles.card}>{f}</div>)}
      </main>
    </div>
  );
};

export default Features;
