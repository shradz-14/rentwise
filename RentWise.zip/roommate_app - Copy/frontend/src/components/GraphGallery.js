import { useEffect, useState } from "react";
import axios from "axios";

function GraphGallery() {
  const [graphs, setGraphs] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:5000/api/graphs").then((res) => {
      setGraphs(res.data.graphs);
    });
  }, []);

  return (
    <div style={{ display: "flex", gap: "20px", flexWrap: "wrap" }}>
      {graphs.map((g, idx) => (
        <img
          key={idx}
          src={`http://localhost:5000/${g}`}
          alt={`Graph ${idx}`}
          style={{ width: "300px", borderRadius: "8px", boxShadow: "0 2px 6px rgba(0,0,0,0.2)" }}
        />
      ))}
    </div>
  );
}

export default GraphGallery;
