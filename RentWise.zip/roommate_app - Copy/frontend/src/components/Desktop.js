import React from "react";
import logo from "../assets/image-bg.png";
import image1 from "../assets/image-1.png";
import image2 from "../assets/image-2.png";
import image3 from "../assets/image-3.png"; // background

const Desktop = () => {
  const user = JSON.parse(localStorage.getItem("user"));

  const styles = {
    container: {
      fontFamily: "Helvetica, Arial, sans-serif",
      backgroundColor: "#162850",
      color: "white",
      minHeight: "94vh",
      overflowX: "hidden",
      position: "relative",
    },
    header: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      padding: "0px 10px",
      backgroundColor: "#fff",
      color: "#000",
      position: "sticky",
      top: 0,
      zIndex: 10,
    },
    logo: { height: "80px", marginBottom: "10px" },
    nav: { display: "flex", gap: "20px", fontSize: "18px" },
    navLink: { textDecoration: "none", color: "black" },
    button: {
      backgroundColor: "#4F90FF",
      color: "white",
      padding: "10px 20px",
      borderRadius: "25px",
      fontWeight: "bold",
      cursor: "pointer",
      textDecoration: "none",
    },
    main: { display: "flex", justifyContent: "space-between", padding: "20px 80px" },
    heroText: { maxWidth: "600px" },
    heroTitle: { fontSize: "3rem", lineHeight: "1.2", marginBottom: "10px" },
    heroDesc: { fontSize: "1.2rem", lineHeight: "1.6" },
    imagesContainer: { position: "relative", width: "500px", height: "450px" },
    image1: { position: "absolute", width: "280px", top: "30px", left: "80px", borderRadius: "10px" },
    image2: { position: "absolute", width: "250px", top: "200px", left: "-20px", borderRadius: "10px" },
    background: { position: "absolute", top: 0, left: 0, width: "100%", height: "100%", objectFit: "cover", zIndex: -1, opacity: 0.2 },
  };

  return (
    <div style={styles.container}>
      <img src={image3} alt="Background" style={styles.background} />

      <header style={styles.header}>
        <img src={logo} alt="Logo" style={styles.logo} />
        <nav style={styles.nav}>
          <a href="/features" style={styles.navLink}>Features</a>
          <a href="/HowItWorks" style={styles.navLink}>How It Works</a>
          {!user ? (
            <a href="/login" style={styles.button}>Login</a>
          ) : (
            <a href="/dashboard" style={styles.button}>Dashboard</a>
          )}
        </nav>
      </header>

      <main style={styles.main}>
        <div style={styles.heroText}>
          <h1 style={styles.heroTitle}>Find your perfect roommate match.</h1>
          <p style={styles.heroDesc}>
            We match you based on habits, values, and lifestyle. Living well starts with the right person.
          </p>
        </div>
        <div style={styles.imagesContainer}>
          <img src={image1} alt="Example1" style={styles.image1} />
          <img src={image2} alt="Example2" style={styles.image2} />
        </div>
      </main>
    </div>
  );
};

export default Desktop;
