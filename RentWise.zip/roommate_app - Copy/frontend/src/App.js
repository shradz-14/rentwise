import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Desktop from "./components/Desktop";
import Features from "./components/Features";
import HowItWorks from "./components/HowItWorks";
import Login from "./components/Login";
import Signup from "./components/Signup";
import Welcome from "./components/Welcome";
import Dashboard from "./components/Dashboard";
import Preference from "./components/Preference";
import UserSearch from "./components/UserSearch";
import Profile from "./components/profile";
import ExpenseDashboard from "./components/ExpenseDashboard";

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Desktop />} />
        <Route path="/Features" element={<Features />} />
        <Route path="/HowItWorks" element={<HowItWorks />} />
        <Route path="/Login" element={<Login />} />
        <Route path="/Signup" element={<Signup />} />
        <Route path="/Welcome" element={<Welcome />} />
        <Route path="/Dashboard" element={<Dashboard />} />
        <Route path="/Preference" element={<Preference />} />
        <Route path="/UserSearch" element={<UserSearch />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/ExpenseDashboard" element={<ExpenseDashboard />} />
      </Routes>
    </Router>
  );
}

export default App;
