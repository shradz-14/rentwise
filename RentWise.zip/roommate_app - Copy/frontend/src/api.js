import axios from "axios";

const BASE_URL = "http://127.0.0.1:8000"; // your FastAPI backend

export const createUser = (userData) => axios.post(`${BASE_URL}/users`, userData);
export const getUsers = () => axios.get(`${BASE_URL}/users`);
export const setPreferences = (prefsData) => axios.post(`${BASE_URL}/preferences`, prefsData);
export const getCompatibility = (prefsData) => axios.post(`${BASE_URL}/compatibility`, prefsData);
export const addExpense = (expenseData) => axios.post(`${BASE_URL}/expenses`, expenseData);
export const getExpenses = () => axios.get(`${BASE_URL}/expenses`);
