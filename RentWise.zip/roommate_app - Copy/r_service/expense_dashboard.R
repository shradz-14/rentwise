library(shiny)
library(ggplot2)
library(DBI)
library(RMySQL)

con <- dbConnect(
  RMySQL::MySQL(),
  dbname = 'roommate_app',
  host = 'db',
  user = 'root',
  password = 'password'
)

ui <- fluidPage(
  titlePanel("Expense Dashboard"),
  sidebarLayout(
    sidebarPanel(),
    mainPanel(
      plotOutput("monthlyPlot")
    )
  )
)

server <- function(input, output) {
  output$monthlyPlot <- renderPlot({
    expenses <- dbGetQuery(con, "SELECT * FROM expenses")
    expenses$date <- as.Date(expenses$date)
    monthly <- aggregate(amount ~ format(date, "%Y-%m"), data=expenses, sum)
    ggplot(monthly, aes(x=`format(date, "%Y-%m")`, y=amount)) +
      geom_bar(stat="identity", fill="steelblue") +
      xlab("Month") + ylab("Total Expense") +
      theme_minimal()
  })
}

shinyApp(ui=ui, server=server)
