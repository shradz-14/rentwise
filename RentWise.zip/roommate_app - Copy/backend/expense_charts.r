# ============================================================
# RentWise - Roommate Expense Chart Generator
# Author: Shraddha Bansal
# Theme: Blue & Grey (consistent with RentWise UI)
# Supports: daily, weekly, monthly trend views
# ============================================================

library(DBI)
library(RMariaDB)
library(ggplot2)
library(jsonlite)
library(dplyr)
library(lubridate)

# -------------------- Step 1: Detect script directory safely --------------------
get_script_path <- function() {
  cmdArgs <- commandArgs(trailingOnly = FALSE)
  needle <- "--file="
  match <- grep(needle, cmdArgs)
  if (length(match) > 0) {
    normalizePath(sub(needle, "", cmdArgs[match]))
  } else if (!is.null(sys.frames()[[1]]$ofile)) {
    normalizePath(sys.frames()[[1]]$ofile)
  } else {
    getwd()
  }
}

script_dir <- dirname(get_script_path())
config_file <- file.path(script_dir, "current_user.json")

# ===== DEBUG LOGGING =====
cat("🔍 DEBUG: Script directory:", script_dir, "\n")
cat("🔍 DEBUG: Config file path:", config_file, "\n")
cat("🔍 DEBUG: Config file exists?", file.exists(config_file), "\n")
# =========================

# -------------------- Step 2: Load user config --------------------
if (!file.exists(config_file)) {
  cat("❌ ERROR: current_user.json not found in", script_dir, "\n")
  quit(save = "no", status = 1)
}

# Wait a moment to ensure file is fully written
Sys.sleep(0.2)

# Read and parse JSON
config <- fromJSON(config_file)

# ===== DEBUG LOGGING =====
cat("🔍 DEBUG: Raw config content:\n")
print(config)
cat("🔍 DEBUG: config$user_id value:", config$user_id, "\n")
cat("🔍 DEBUG: config$user_id type:", class(config$user_id), "\n")
# =========================

current_user_id <- as.integer(config$user_id)

# ===== DEBUG LOGGING =====
cat("🔍 DEBUG: After as.integer, current_user_id:", current_user_id, "\n")
cat("🔍 DEBUG: Is NA?", is.na(current_user_id), "\n")
# =========================

if (is.na(current_user_id)) {
  cat("❌ ERROR: Invalid or missing user_id in JSON config.\n")
  quit(save = "no", status = 1)
}

cat("✅ INFO: Generating charts for user ID:", current_user_id, "\n")

# -------------------- Step 3: Connect to Database --------------------
con <- dbConnect(
  RMariaDB::MariaDB(),
  user = "root",
  password = "shraddha-1401",
  host = "localhost",
  dbname = "roommate_app"
)

# -------------------- Step 4: Fetch Expense Data --------------------
query <- sprintf("
  SELECT id, description, amount, category, paid_by, user_id, date
  FROM expenses
  WHERE user_id = %d OR paid_by = %d OR JSON_CONTAINS(split_with, CAST(%d AS JSON))
  ORDER BY date DESC;
", current_user_id, current_user_id, current_user_id)

cat("🔍 DEBUG: Executing query for user_id:", current_user_id, "\n")

expenses <- dbGetQuery(con, query)

cat("🔍 DEBUG: Found", nrow(expenses), "expenses\n")

if (nrow(expenses) == 0) {
  cat('⚠️ No expenses found for user ID:', current_user_id, '\n')
  dbDisconnect(con)
  quit(save = "no")
}

# Clean data
expenses$amount <- as.numeric(expenses$amount)
expenses$category[is.na(expenses$category) | expenses$category == ""] <- "Other"
expenses$date <- as.Date(expenses$date)

# -------------------- Step 5: Prepare folder for saving --------------------
backend_www <- file.path(script_dir, "www")
user_folder <- file.path(backend_www, paste0("user_", current_user_id))

cat("🔍 DEBUG: Creating folder:", user_folder, "\n")

if (!dir.exists(backend_www)) dir.create(backend_www, recursive = TRUE)
if (!dir.exists(user_folder)) dir.create(user_folder, recursive = TRUE)

output_dir <- user_folder
cat("📁 Output Directory:", output_dir, "\n")

# -------------------- Step 6: Define Custom Blue-Grey Theme --------------------
theme_colors <- c(
  "#4F90FF",  # Primary Blue
  "#1E3A8A",  # Dark Blue
  "#60A5FA",  # Light Blue
  "#3B82F6",  # Medium Blue
  "#9CA3AF",  # Grey
  "#6B7280",  # Dark Grey
  "#D1D5DB",  # Light Grey
  "#E5E7EB"   # Very Light Grey
)

custom_theme <- theme_minimal(base_size = 14) +
  theme(
    plot.title = element_text(face = "bold", color = "#1E3A8A", size = 16, hjust = 0.5),
    axis.title = element_text(color = "#1E3A8A"),
    axis.text = element_text(color = "#374151"),
    panel.grid.major = element_line(color = "#E5E7EB"),
    panel.grid.minor = element_blank(),
    plot.background = element_rect(fill = "white", color = NA)
  )

# -------------------- Step 7: Create and Save Charts --------------------

cat("📊 Generating Chart 1/7: bar_expense.png\n")
## 1️⃣ Bar Chart - Expense by Category
category_totals <- expenses %>%
  group_by(category) %>%
  summarise(total = sum(amount, na.rm = TRUE))

if (nrow(category_totals) > 0) {
  p1 <- ggplot(category_totals, aes(x = reorder(category, -total), y = total, fill = category)) +
    geom_bar(stat = "identity", width = 0.7) +
    geom_text(aes(label = paste0("₹", round(total, 0))), 
              vjust = -0.5, 
              color = "#1E3A8A", 
              fontface = "bold", 
              size = 4) +
    scale_fill_manual(values = theme_colors) +
    labs(title = "Expenses by Category", x = "Category", y = "Total Amount (₹)") +
    custom_theme +
    theme(legend.position = "none") +
    scale_y_continuous(limits = c(0, max(category_totals$total) * 1.15))
  
  ggsave(file.path(output_dir, "bar_expense.png"), plot = p1, width = 7, height = 5, dpi = 300)
  cat("   ✅ Saved: bar_expense.png\n")
}

cat("📊 Generating Chart 2/7: pie_expense.png\n")
## 2️⃣ Pie Chart - Category Distribution
category_sums <- expenses %>%
  group_by(category) %>%
  summarise(total = sum(amount, na.rm = TRUE))

if (nrow(category_sums) > 0) {
  category_sums$fraction <- category_sums$total / sum(category_sums$total)
  category_sums$percentage <- round(category_sums$fraction * 100, 1)
  category_sums$label <- paste0(category_sums$category, "\n", category_sums$percentage, "%")
  
  p2 <- ggplot(category_sums, aes(x = "", y = fraction, fill = category)) +
    geom_col(width = 1, color = "white") +
    coord_polar(theta = "y") +
    scale_fill_manual(values = theme_colors) +
    geom_text(aes(label = label), position = position_stack(vjust = 0.5), size = 4, color = "white", fontface = "bold") +
    labs(title = "Category-Wise Expense Distribution") +
    theme_void(base_size = 14) +
    theme(plot.title = element_text(hjust = 0.5, face = "bold", color = "#1E3A8A", size = 16))
  
  ggsave(file.path(output_dir, "pie_expense.png"), plot = p2, width = 6, height = 6, dpi = 300)
  cat("   ✅ Saved: pie_expense.png\n")
}

cat("📊 Generating Chart 3/7: line_expense.png (Monthly - Default)\n")
## 3️⃣ Line Chart - Monthly Trend (Default)
expenses$month <- format(expenses$date, "%Y-%m")
monthly_trend <- expenses %>%
  group_by(month) %>%
  summarise(total = sum(amount, na.rm = TRUE))

if (nrow(monthly_trend) > 0) {
  p3 <- ggplot(monthly_trend, aes(x = month, y = total, group = 1)) +
    geom_line(color = "#4F90FF", size = 1.2) +
    geom_point(size = 3, color = "#1E3A8A") +
    geom_text(aes(label = paste0("₹", round(total, 0))), 
              vjust = -1, 
              color = "#1E3A8A", 
              fontface = "bold", 
              size = 3.5) +
    labs(title = "Monthly Spending Trend", x = "Month", y = "Total Spent (₹)") +
    custom_theme +
    scale_y_continuous(limits = c(0, max(monthly_trend$total) * 1.15))
  
  ggsave(file.path(output_dir, "line_expense.png"), plot = p3, width = 7, height = 5, dpi = 300)
  cat("   ✅ Saved: line_expense.png\n")
}

cat("📊 Generating Chart 4/7: line_expense_daily.png\n")
## 4️⃣ Line Chart - DAILY Trend
daily_trend <- expenses %>%
  group_by(date) %>%
  summarise(total = sum(amount, na.rm = TRUE))

if (nrow(daily_trend) > 0) {
  p4 <- ggplot(daily_trend, aes(x = date, y = total, group = 1)) +
    geom_line(color = "#4F90FF", size = 1.2) +
    geom_point(size = 2.5, color = "#1E3A8A") +
    geom_text(aes(label = paste0("₹", round(total, 0))), 
              vjust = -1, 
              color = "#1E3A8A", 
              fontface = "bold", 
              size = 3) +
    labs(title = "Daily Spending Trend", x = "Date", y = "Total Spent (₹)") +
    custom_theme +
    theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
    scale_y_continuous(limits = c(0, max(daily_trend$total) * 1.15))
  
  ggsave(file.path(output_dir, "line_expense_daily.png"), plot = p4, width = 8, height = 5, dpi = 300)
  cat("   ✅ Saved: line_expense_daily.png\n")
}

cat("📊 Generating Chart 5/7: line_expense_weekly.png\n")
## 5️⃣ Line Chart - WEEKLY Trend
expenses$week <- floor_date(expenses$date, "week")
weekly_trend <- expenses %>%
  group_by(week) %>%
  summarise(total = sum(amount, na.rm = TRUE))

if (nrow(weekly_trend) > 0) {
  p5 <- ggplot(weekly_trend, aes(x = week, y = total, group = 1)) +
    geom_line(color = "#4F90FF", size = 1.2) +
    geom_point(size = 3, color = "#1E3A8A") +
    geom_text(aes(label = paste0("₹", round(total, 0))), 
              vjust = -1, 
              color = "#1E3A8A", 
              fontface = "bold", 
              size = 3.5) +
    labs(title = "Weekly Spending Trend", x = "Week Starting", y = "Total Spent (₹)") +
    custom_theme +
    scale_y_continuous(limits = c(0, max(weekly_trend$total) * 1.15))
  
  ggsave(file.path(output_dir, "line_expense_weekly.png"), plot = p5, width = 7, height = 5, dpi = 300)
  cat("   ✅ Saved: line_expense_weekly.png\n")
}

cat("📊 Generating Chart 6/7: roommate_contrib.png\n")
## 6️⃣ Roommate Contributions
payer_totals <- expenses %>%
  group_by(paid_by) %>%
  summarise(total = sum(amount, na.rm = TRUE))

if (nrow(payer_totals) > 0) {
  payer_names <- character(nrow(payer_totals))
  for (i in 1:nrow(payer_totals)) {
    user_query <- sprintf("SELECT name FROM users WHERE id = %d", payer_totals$paid_by[i])
    user_result <- dbGetQuery(con, user_query)
    if (nrow(user_result) > 0) {
      payer_names[i] <- user_result$name[1]
    } else {
      payer_names[i] <- paste0("User ", payer_totals$paid_by[i])
    }
  }
  payer_totals$payer_name <- payer_names
  
  p6 <- ggplot(payer_totals, aes(x = reorder(payer_name, -total), y = total, fill = payer_name)) +
    geom_bar(stat = "identity", width = 0.6) +
    geom_text(aes(label = paste0("₹", round(total, 0))), 
              vjust = -0.5, 
              color = "#1E3A8A", 
              fontface = "bold", 
              size = 4) +
    scale_fill_manual(values = theme_colors) +
    labs(title = "Roommate Contributions", x = "Person", y = "Total Paid (₹)") +
    custom_theme +
    theme(legend.position = "none") +
    scale_y_continuous(limits = c(0, max(payer_totals$total) * 1.15))
  
  ggsave(file.path(output_dir, "roommate_contrib.png"), plot = p6, width = 7, height = 5, dpi = 300)
  cat("   ✅ Saved: roommate_contrib.png\n")
}

cat("📊 Generating Chart 7/7: top_expenses.png (Bonus)\n")
## 7️⃣ BONUS: Top 5 Expenses
top_exp <- head(expenses[order(-expenses$amount), ], 5)

if (nrow(top_exp) > 0) {
  p7 <- ggplot(top_exp, aes(x = reorder(description, amount), y = amount, fill = category)) +
    geom_bar(stat = "identity", width = 0.6) +
    geom_text(aes(label = paste0("₹", round(amount, 0))), 
              hjust = -0.2, 
              color = "#1E3A8A", 
              fontface = "bold", 
              size = 3.5) +
    scale_fill_manual(values = theme_colors) +
    coord_flip() +
    labs(title = "Top 5 Highest Expenses", x = "Description", y = "Amount (₹)") +
    custom_theme +
    scale_y_continuous(limits = c(0, max(top_exp$amount) * 1.2))
  
  ggsave(file.path(output_dir, "top_expenses.png"), plot = p7, width = 7, height = 5, dpi = 300)
  cat("   ✅ Saved: top_expenses.png\n")
}

# -------------------- Step 8: Close DB Connection --------------------
dbDisconnect(con)

cat("\n🎉 SUCCESS! All charts generated and saved in:", output_dir, "\n")
cat("📋 Files created:\n")
cat("   1. bar_expense.png\n")
cat("   2. pie_expense.png\n")
cat("   3. line_expense.png (monthly - default)\n")
cat("   4. line_expense_daily.png (NEW!)\n")
cat("   5. line_expense_weekly.png (NEW!)\n")
cat("   6. roommate_contrib.png\n")