import express from "express";
import mysql from "mysql2/promise";
import bcrypt from "bcryptjs";
import cors from "cors";
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";
import fs from "fs";
import { exec } from "child_process";
import nodemailer from "nodemailer";


dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PORT = process.env.PORT || 5000;

const app = express();
app.use(express.json());
app.use(cors({ origin: process.env.CORS_ORIGIN || "http://localhost:3000" }));

// MySQL pool
const pool = mysql.createPool({
  host: process.env.DB_HOST || "localhost",
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASS || "shraddha-1401",
  database: process.env.DB_NAME || "roommate_app",
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});

// ============================================
// HELPER FUNCTIONS
// ============================================

// Helper function to classify category
function classifyCategory(description) {
  if (!description || typeof description !== "string") return "other";
  const desc = description.toLowerCase();
  if (/rent|lease|apartment|house/.test(desc)) return "rent";
  if (/electricity|water bill|gas bill|utilities|power/.test(desc)) return "utilities";
  if (/grocery|vegetables|fruits|supermarket|market|food|meat|dairy/.test(desc)) return "groceries";
  if (/pen|notebook|stationery|paper|printer ink|pencil|scissor/.test(desc)) return "stationery";
  if (/taxi|uber|cab|bus|train|transport|fuel|gasoline|petrol/.test(desc)) return "transportation";
  if (/movie|cinema|concert|game|entertainment|music|netflix|spotify/.test(desc)) return "entertainment";
  if (/cleaning|detergent|soap|broom|mop|vacuum/.test(desc)) return "cleaning";
  if (/internet|wifi|broadband|data plan|mobile data/.test(desc)) return "internet";
  return "other";
}

// ============================================
// R SCRIPT QUEUE SYSTEM (IMPROVED)
// ============================================

let rScriptQueue = [];
let isProcessingRScript = false;

// Process R script queue one at a time
async function processRScriptQueue() {
  const timestamp = new Date().toISOString();
  console.log(`\n${'='.repeat(60)}`);
  console.log(`🔍 [${timestamp}] processRScriptQueue called`);
  console.log(`   isProcessing: ${isProcessingRScript}`);
  console.log(`   queueLength: ${rScriptQueue.length}`);
  console.log(`   queue contents: [${rScriptQueue.join(', ')}]`);
  console.log('='.repeat(60));
  
  if (isProcessingRScript) {
    console.log(`⏸️ [QUEUE] Already processing, exiting`);
    return;
  }
  
  if (rScriptQueue.length === 0) {
    console.log(`⏸️ [QUEUE] Queue is empty, exiting`);
    return;
  }

  isProcessingRScript = true;
  const userId = rScriptQueue.shift();

  console.log(`\n🔄 [QUEUE] Starting R script for user ID: ${userId}`);
  console.log(`   Remaining in queue: ${rScriptQueue.length}`);

  try {
    // Update the main current_user.json
    const mainJsonPath = path.join(__dirname, "current_user.json");
    const currentUserData = { user_id: userId };
    
    console.log(`📝 [FILE] Writing to: ${mainJsonPath}`);
    console.log(`   Data: ${JSON.stringify(currentUserData)}`);
    
    // Write synchronously and verify
    fs.writeFileSync(mainJsonPath, JSON.stringify(currentUserData, null, 2), 'utf8');
    
    // Verify the write was successful by reading it back
    const verifyContent = fs.readFileSync(mainJsonPath, 'utf8');
    const verifyData = JSON.parse(verifyContent);
    
    if (verifyData.user_id !== userId) {
      throw new Error(`File write verification failed! Expected ${userId}, got ${verifyData.user_id}`);
    }
    
    console.log(`✅ [FILE] current_user.json verified with user_id: ${userId}`);

    // Check if R script exists
    const rScriptPath = path.join(__dirname, "expense_charts.R");
    if (!fs.existsSync(rScriptPath)) {
      throw new Error(`R script not found at: ${rScriptPath}`);
    }
    console.log(`✅ [FILE] R script found at: ${rScriptPath}`);

    // Execute R script and wait for completion
    console.log(`🎯 [EXEC] Executing: Rscript "${rScriptPath}"`);
    console.log(`   Working directory: ${__dirname}`);
    
    await new Promise((resolve, reject) => {
      const startTime = Date.now();
      
      exec(`Rscript "${rScriptPath}"`, 
        { 
          cwd: __dirname,
          timeout: 60000, // 60 second timeout
          maxBuffer: 1024 * 1024 * 10 // 10MB buffer
        }, 
        (error, stdout, stderr) => {
          const duration = ((Date.now() - startTime) / 1000).toFixed(2);
          
          if (error) {
            console.error(`\n❌ [EXEC] R script failed for user ${userId} (${duration}s)`);
            console.error(`   Error code: ${error.code}`);
            console.error(`   Error message: ${error.message}`);
            if (stderr) console.error(`   stderr: ${stderr}`);
            if (stdout) console.error(`   stdout: ${stdout}`);
            reject(error);
          } else {
            console.log(`\n✅ [EXEC] R script completed successfully for user ${userId} (${duration}s)`);
            if (stdout) console.log(`   stdout: ${stdout.trim()}`);
            if (stderr) console.warn(`   ⚠️ stderr: ${stderr.trim()}`);
            resolve();
          }
        }
      );
    });

  } catch (err) {
    console.error(`\n⚠️ [ERROR] Error in R script execution for user ${userId}:`);
    console.error(`   ${err.message}`);
    console.error(`   Stack: ${err.stack}`);
  } finally {
    isProcessingRScript = false;
    console.log(`\n✅ [QUEUE] Finished processing user ${userId}`);
    console.log(`   Setting isProcessing to false`);
    
    // Process next item in queue after a small delay
    if (rScriptQueue.length > 0) {
      console.log(`⏭️ [QUEUE] ${rScriptQueue.length} items remaining, processing next in 500ms...`);
      setTimeout(() => {
        processRScriptQueue().catch(err => {
          console.error('Error in queue processing:', err);
        });
      }, 500);
    } else {
      console.log(`🎉 [QUEUE] All done! Queue is empty.\n`);
    }
  }
}

// Unified R Script Trigger Function with Queue
function triggerRScriptGeneration(userId) {
  const timestamp = new Date().toISOString();
  console.log(`\n${'*'.repeat(60)}`);
  console.log(`🚀 [${timestamp}] triggerRScriptGeneration CALLED`);
  console.log(`   userId: ${userId}`);
  console.log(`   current queue before: [${rScriptQueue.join(', ')}]`);
  console.log(`   isProcessing: ${isProcessingRScript}`);
  
  // Validate userId
  if (!userId) {
    console.error(`❌ [TRIGGER] Invalid userId provided: ${userId}`);
    return;
  }
  
  const userIdNum = Number(userId);
  if (isNaN(userIdNum)) {
    console.error(`❌ [TRIGGER] userId is not a number: ${userId}`);
    return;
  }
  
  // Add to queue if not already present
  if (!rScriptQueue.includes(userIdNum)) {
    rScriptQueue.push(userIdNum);
    console.log(`✅ [TRIGGER] User ${userIdNum} added to queue`);
    console.log(`   Queue length: ${rScriptQueue.length}`);
    console.log(`   Current queue: [${rScriptQueue.join(', ')}]`);
  } else {
    console.log(`⏭️ [TRIGGER] User ${userIdNum} already in queue, skipping duplicate`);
  }

  console.log('*'.repeat(60));
  
  // Start processing if not already running
  console.log(`🔄 [TRIGGER] Calling processRScriptQueue...`);
  
  // Use setImmediate to ensure this runs in next event loop iteration
  setImmediate(() => {
    processRScriptQueue().catch(err => {
      console.error('Error starting queue processing:', err);
    });
  });
}

// Trigger Python Recommendation Update
function triggerRecommendationUpdate() {
  console.log("\n🤖 Triggering AI recommendation update...");
  
  const pythonScriptPath = path.join(__dirname, "recommendation.py");
  
  // Check if Python script exists
  if (!fs.existsSync(pythonScriptPath)) {
    console.error(`❌ Python script not found at: ${pythonScriptPath}`);
    return;
  }
  
  exec("python3 recommendation.py", { cwd: __dirname }, (err, stdout, stderr) => {
    if (err) {
      console.error("❌ AI Recommendation Error:", err.message);
      return;
    }
    if (stderr) console.warn("⚠️ Python stderr:", stderr);
    console.log("✅ AI Recommendations updated!");
    if (stdout) console.log("stdout:", stdout);
  });
}

// ============================================
// STATIC FILES
// ============================================
app.use("/charts", express.static(path.resolve("./www"), { extensions: ["png", "jpg", "jpeg"] }));

// Request logging middleware
app.use((req, res, next) => {
  console.log(`📥 [${new Date().toISOString()}] ${req.method} ${req.path}`);
  next();
});

// ============================================
// DEBUG ENDPOINTS (for testing)
// ============================================

app.get("/api/debug/check-files", (req, res) => {
  const rScriptPath = path.join(__dirname, "expense_charts.R");
  const jsonPath = path.join(__dirname, "current_user.json");
  
  res.json({
    rScriptExists: fs.existsSync(rScriptPath),
    rScriptPath: rScriptPath,
    jsonExists: fs.existsSync(jsonPath),
    jsonPath: jsonPath,
    __dirname: __dirname,
    queueStatus: {
      isProcessing: isProcessingRScript,
      queueLength: rScriptQueue.length,
      queue: [...rScriptQueue]
    }
  });
});

app.post("/api/debug/trigger-r/:userId", (req, res) => {
  const userId = req.params.userId;
  console.log(`🧪 [DEBUG] Manual R script trigger for user ${userId}`);
  triggerRScriptGeneration(userId);
  res.json({ 
    message: `Triggered R script for user ${userId}`,
    queueLength: rScriptQueue.length 
  });
});

app.get("/api/debug/test-flow/:userId", async (req, res) => {
  const userId = req.params.userId;
  const results = {};
  
  try {
    // 1. Check if user exists
    const [userRows] = await pool.query("SELECT id, username FROM users WHERE id = ?", [userId]);
    results.userExists = userRows.length > 0;
    results.user = userRows[0] || null;
    
    // 2. Check if R script exists
    const rScriptPath = path.join(__dirname, "expense_charts.R");
    results.rScriptExists = fs.existsSync(rScriptPath);
    results.rScriptPath = rScriptPath;
    
    // 3. Check if current_user.json exists
    const jsonPath = path.join(__dirname, "current_user.json");
    results.jsonExists = fs.existsSync(jsonPath);
    
    // 4. Try to write current_user.json
    try {
      fs.writeFileSync(jsonPath, JSON.stringify({ user_id: parseInt(userId) }, null, 2));
      results.jsonWriteSuccess = true;
      results.jsonContent = JSON.parse(fs.readFileSync(jsonPath, 'utf8'));
    } catch (e) {
      results.jsonWriteSuccess = false;
      results.jsonError = e.message;
    }
    
    // 5. Check queue status
    results.queueStatus = {
      isProcessing: isProcessingRScript,
      queueLength: rScriptQueue.length,
      queue: [...rScriptQueue]
    };
    
    // 6. Trigger R script
    console.log("🧪 Test: Triggering R script...");
    triggerRScriptGeneration(userId);
    
    results.triggerAttempted = true;
    
    res.json(results);
  } catch (err) {
    res.status(500).json({ error: err.message, results });
  }
});

// NEW: Test endpoint to simulate adding an expense
app.post("/api/debug/test-add-expense", async (req, res) => {
  console.log("\n" + "🧪".repeat(30));
  console.log("🧪 DEBUG: TEST ADD EXPENSE");
  console.log("🧪".repeat(30));
  
  try {
    const userId = req.body.userId || 1;
    
    // Add a test expense
    const testExpense = {
      userId: userId,
      description: "Test Grocery Shopping",
      amount: 50.00,
      paidBy: userId,
      splitShares: [],
      date: new Date().toISOString()
    };
    
    console.log("📝 Test expense data:", testExpense);
    
    // Insert test expense
    const [result] = await pool.query(
      `INSERT INTO expenses (user_id, description, amount, category, paid_by, split_with, date, paid, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, false, NOW())`,
      [testExpense.userId, testExpense.description, testExpense.amount, 'groceries', 
       testExpense.paidBy, JSON.stringify([userId]), testExpense.date]
    );
    
    const expenseId = result.insertId;
    console.log(`✅ Test expense added with ID: ${expenseId}`);
    
    // Manually trigger R script
    console.log(`\n🎯 Manually triggering R script for user ${userId}...`);
    triggerRScriptGeneration(userId);
    
    // Wait a bit and check queue status
    setTimeout(() => {
      console.log("\n📊 Queue status after 2 seconds:");
      console.log(`   isProcessing: ${isProcessingRScript}`);
      console.log(`   queueLength: ${rScriptQueue.length}`);
      console.log(`   queue: [${rScriptQueue.join(', ')}]`);
    }, 2000);
    
    res.json({
      message: "Test expense added and R script triggered",
      expenseId,
      userId,
      queueStatus: {
        isProcessing: isProcessingRScript,
        queueLength: rScriptQueue.length,
        queue: [...rScriptQueue]
      }
    });
    
  } catch (err) {
    console.error("❌ Test add expense error:", err);
    res.status(500).json({ error: err.message });
  }
});

// ============================================
// AUTH ENDPOINTS
// ============================================

// Signup
app.post("/api/signup", async (req, res) => {
  try {
    const { username, name, email, password } = req.body;
    if (!username || !name || !email || !password)
      return res.status(400).json({ error: "All fields are required" });

    const [existing] = await pool.query(
      "SELECT id FROM users WHERE email = ? OR username = ?",
      [email, username]
    );
    if (existing.length) return res.status(400).json({ error: "Email or Username already registered" });

    const hashed = await bcrypt.hash(password, 10);
    await pool.query(
      "INSERT INTO users (username, name, email, password) VALUES (?, ?, ?, ?)",
      [username, name, email, hashed]
    );

    res.json({ message: "Signup successful" });
  } catch (err) {
    console.error("SIGNUP ERR", err);
    res.status(500).json({ error: "Server error" });
  }
});

// Login
app.post("/api/login", async (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password)
      return res.status(400).json({ error: "Username and password required" });

    const [rows] = await pool.query(
      "SELECT id, name, username, password FROM users WHERE username = ?",
      [username]
    );
    if (!rows.length) return res.status(400).json({ error: "User not found" });

    const user = rows[0];
    const match = await bcrypt.compare(password, user.password);
    if (!match) return res.status(400).json({ error: "Invalid credentials" });

    console.log("\n" + "=".repeat(60));
    console.log("🔐 LOGIN SUCCESS");
    console.log(`   User ID: ${user.id}`);
    console.log(`   Username: ${user.username}`);
    console.log(`   Timestamp: ${new Date().toISOString()}`);
    console.log("=".repeat(60));
    
    // ✅ Trigger R script generation for this user
    console.log("🎯 Triggering R script generation...");
    
    try {
      triggerRScriptGeneration(user.id);
      console.log("✅ R script trigger initiated successfully");
    } catch (triggerError) {
      console.error("❌ Error triggering R script:", triggerError);
      // Don't fail the login if R script fails
    }

    // Send login success response
    res.json({
      message: "Login successful",
      user: { id: user.id, username: user.username, name: user.name },
    });

  } catch (err) {
    console.error("❌ LOGIN ERROR:", err);
    res.status(500).json({ error: "Server error" });
  }
});

// ============================================
// USER & PREFERENCES
// ============================================

app.get("/api/user/:userId", async (req, res) => {
  try {
    const userId = req.params.userId;
    const [userRows] = await pool.query("SELECT id, username, name, email FROM users WHERE id = ?", [userId]);
    if (!userRows.length) return res.status(404).json({ error: "User not found" });
    const user = userRows[0];

    const [prefsRows] = await pool.query("SELECT * FROM preferences WHERE user_id = ?", [userId]);
    let preferences = prefsRows.length > 0 ? { ...prefsRows[0] } : null;

    res.json({ ...user, preferences });
  } catch (err) {
    console.error("GET USER ERR", err);
    res.status(500).json({ error: "Server error" });
  }
});

app.get("/api/preferences/:userId", async (req, res) => {
  try {
    const userId = req.params.userId;
    const [rows] = await pool.query("SELECT * FROM preferences WHERE user_id = ?", [userId]);
    res.json({ filled: rows.length > 0 });
  } catch (err) {
    console.error("PREFERENCES CHECK ERR", err);
    res.status(500).json({ error: "Server error" });
  }
});

app.post("/api/preferences/:userId", async (req, res) => {
  try {
    const userId = req.params.userId;
    const data = req.body;
    const [existing] = await pool.query("SELECT id FROM preferences WHERE user_id = ?", [userId]);

    if (existing.length) {
      await pool.query(
        `UPDATE preferences SET 
          sleep_schedule=?, cleanliness=?, smoking=?, alcohol=?, guests_allowed=?, 
          social_style=?, sharing_items=?, talkativeness=?, work_schedule=?, quiet_hours=?, 
          budget_range=?, location=? 
         WHERE user_id=?`,
        [
          data.sleep_schedule, data.cleanliness, data.smoking, data.alcohol, data.guests_allowed,
          data.social_style, data.sharing_items, data.talkativeness, data.work_schedule,
          data.quiet_hours, data.budget_range, data.location, userId
        ]
      );
    } else {
      await pool.query(
        `INSERT INTO preferences 
          (user_id, sleep_schedule, cleanliness, smoking, alcohol, guests_allowed, social_style, sharing_items, talkativeness, work_schedule, quiet_hours, budget_range, location)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          userId, data.sleep_schedule, data.cleanliness, data.smoking, data.alcohol, data.guests_allowed,
          data.social_style, data.sharing_items, data.talkativeness, data.work_schedule,
          data.quiet_hours, data.budget_range, data.location
        ]
      );
    }
    res.json({ message: "Preferences saved successfully" });
  } catch (err) {
    console.error("PREFERENCES SAVE ERR", err);
    res.status(500).json({ error: "Server error" });
  }
});

app.get("/api/searchUser", async (req, res) => {
  try {
    const { username, currentUserId } = req.query;
    if (!username) return res.status(400).json({ error: "Username is required" });

    const [rows] = await pool.query(
      "SELECT * FROM users WHERE LOWER(username) = ? AND id != ?",
      [username.toLowerCase(), currentUserId]
    );

    if (!rows.length) return res.status(404).json({ error: "User not found" });

    const user = rows[0];

    const [prefRows] = await pool.query(
      "SELECT * FROM preferences WHERE user_id = ?",
      [user.id]
    );

    res.json({
      user,
      preferences: prefRows[0] || {},
      compatibilityScore: Math.floor(Math.random() * 50) + 50,
    });
  } catch (err) {
    console.error("SEARCH USER ERR", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

// ============================================
// ROOMMATE MANAGEMENT
// ============================================

app.get("/api/roommate/:userId", async (req, res) => {
  try {
    const userId = req.params.userId;
    const [rows] = await pool.query("SELECT roommate_id FROM users WHERE id = ?", [userId]);
    res.json({ roommate_id: rows.length ? rows[0].roommate_id : null });
  } catch (err) {
    console.error("GET ROOMMATE ERR", err);
    res.status(500).json({ error: "Server error" });
  }
});

app.post("/api/roommate/set", async (req, res) => {
  try {
    const { userId, roommate_id } = req.body;
    if (!userId || !roommate_id) return res.status(400).json({ error: "userId and roommate_id required" });

    await pool.query("UPDATE users SET roommate_id = ? WHERE id = ?", [roommate_id, userId]);
    await pool.query("UPDATE users SET roommate_id = ? WHERE id = ?", [userId, roommate_id]);
    res.json({ message: "Roommate set successfully" });
  } catch (err) {
    console.error("SET ROOMMATE ERR", err);
    res.status(500).json({ error: "Server error" });
  }
});

app.post("/api/roommate/remove", async (req, res) => {
  try {
    const { userId } = req.body;
    if (!userId) return res.status(400).json({ error: "userId required" });

    const [currentUser] = await pool.query("SELECT roommate_id FROM users WHERE id = ?", [userId]);
    const roommateId = currentUser[0]?.roommate_id;

    await pool.query("UPDATE users SET roommate_id = NULL WHERE id = ?", [userId]);
    if (roommateId) await pool.query("UPDATE users SET roommate_id = NULL WHERE id = ?", [roommateId]);
    res.json({ message: "Roommate removed successfully" });
  } catch (err) {
    console.error("REMOVE ROOMMATE ERR", err);
    res.status(500).json({ error: "Server error" });
  }
});

// ============================================
// EXPENSES
// ============================================

// Add expense
app.post("/api/expenses/add", async (req, res) => {
  let expenseAdded = false;
  let expenseId = null;
  let affectedUsers = [];
  
  try {
    const { userId, description, amount, paidBy, splitShares, date } = req.body;
    
    console.log("\n" + "=".repeat(60));
    console.log("💰 ADD EXPENSE REQUEST RECEIVED");
    console.log(`   User ID: ${userId} (type: ${typeof userId})`);
    console.log(`   Description: ${description}`);
    console.log(`   Amount: ${amount}`);
    console.log(`   Paid By: ${paidBy}`);
    console.log(`   Split Shares: ${JSON.stringify(splitShares)}`);
    console.log(`   Date: ${date}`);
    console.log("=".repeat(60));
    
    // Validation
    if (!userId || !description || !amount || amount <= 0 || !paidBy) {
      console.log("❌ VALIDATION FAILED");
      return res.status(400).json({ error: "Required fields missing or invalid" });
    }

    // Fetch roommate if exists
    const [userRows] = await pool.query("SELECT roommate_id FROM users WHERE id = ?", [userId]);
    const roommateId = userRows[0]?.roommate_id;
    
    console.log(`👥 Roommate ID: ${roommateId || 'none'}`);

    // Prepare split IDs
    let splitIds = [...new Set((splitShares || []).map(s => Number(s.id)))];
    splitIds.push(Number(userId));
    if (roommateId) splitIds.push(Number(roommateId));
    splitIds = [...new Set(splitIds)];

    // Classify expense category
    const category = classifyCategory(description);
    
    // Format date
    const sqlDate = date && !isNaN(new Date(date))
      ? new Date(date).toISOString().slice(0, 19).replace("T", " ")
      : new Date().toISOString().slice(0, 19).replace("T", " ");

    console.log(`\n📝 INSERTING EXPENSE INTO DATABASE...`);
    console.log(`   Category: ${category}`);
    console.log(`   Split IDs: [${splitIds.join(', ')}]`);
    console.log(`   SQL Date: ${sqlDate}`);

    // Insert into database
    const [result] = await pool.query(
      `INSERT INTO expenses (user_id, description, amount, category, paid_by, split_with, date, paid, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, false, NOW())`,
      [userId, description, amount, category, paidBy, JSON.stringify(splitIds), sqlDate]
    );

    expenseAdded = true;
    expenseId = result.insertId;
    affectedUsers = [...new Set([Number(userId), Number(paidBy), ...splitIds.map(Number)])];

    console.log("\n" + "✅".repeat(30));
    console.log("✅ EXPENSE SUCCESSFULLY ADDED TO DATABASE");
    console.log(`   Expense ID: ${expenseId}`);
    console.log(`   Category: ${category}`);
    console.log(`   Split with: [${splitIds.join(', ')}]`);
    console.log(`   Affected users: [${affectedUsers.join(', ')}]`);
    console.log("✅".repeat(30));

    // Send response FIRST before triggering R scripts
    const responseData = {
      message: "Expense added successfully",
      id: expenseId,
      category,
      split_with: splitIds
    };

    console.log("\n📤 SENDING RESPONSE TO CLIENT...");
    res.json(responseData);
    console.log("✅ Response sent to client\n");

    // Now trigger R scripts AFTER response is sent
    // Use process.nextTick to ensure response is fully sent
    process.nextTick(() => {
      console.log("\n" + "🎬".repeat(30));
      console.log("🎬 TRIGGERING R SCRIPT GENERATION (AFTER RESPONSE)");
      console.log("🎬".repeat(30));
      
      // Trigger for primary user
      console.log(`\n🎯 [1/3] Triggering R script for primary user ${userId}...`);
      try {
        triggerRScriptGeneration(Number(userId));
        console.log(`✅ R script trigger called for user ${userId}`);
      } catch (triggerErr) {
        console.error(`❌ Failed to trigger R script for user ${userId}:`, triggerErr);
      }

      // Trigger for payer if different from primary user
      if (Number(paidBy) !== Number(userId)) {
        console.log(`\n🎯 [2/3] Triggering R script for payer ${paidBy}...`);
        setTimeout(() => {
          try {
            triggerRScriptGeneration(Number(paidBy));
            console.log(`✅ R script trigger called for payer ${paidBy}`);
          } catch (triggerErr) {
            console.error(`❌ Failed to trigger R script for payer ${paidBy}:`, triggerErr);
          }
        }, 1500);
      }

      // Trigger for roommate if involved
      if (roommateId && splitIds.includes(Number(roommateId))) {
        console.log(`\n🎯 [3/3] Triggering R script for roommate ${roommateId}...`);
        setTimeout(() => {
          try {
            triggerRScriptGeneration(Number(roommateId));
            console.log(`✅ R script trigger called for roommate ${roommateId}`);
          } catch (triggerErr) {
            console.error(`❌ Failed to trigger R script for roommate ${roommateId}:`, triggerErr);
          }
        }, 2500);
      }

      // Trigger AI recommendation update
      console.log("\n🤖 Triggering AI recommendation update...");
      setTimeout(() => {
        try {
          triggerRecommendationUpdate();
          console.log("✅ AI recommendation trigger called");
        } catch (triggerErr) {
          console.error("❌ Failed to trigger AI recommendations:", triggerErr);
        }
      }, 3500);
      
      console.log("\n" + "🎬".repeat(30));
      console.log("🎬 ALL TRIGGERS INITIATED");
      console.log("🎬".repeat(30) + "\n");
    });

  } catch (err) {
    console.error("\n" + "❌".repeat(30));
    console.error("❌ ADD EXPENSE ERROR");
    console.error("❌".repeat(30));
    console.error("Error details:", err);
    console.error("Stack trace:", err.stack);
    
    if (!res.headersSent) {
      return res.status(500).json({ 
        error: "Server error: " + err.message,
        expenseAdded,
        expenseId
      });
    }
  }
});

// Get expenses
app.get("/api/expenses/:userId", async (req, res) => {
  try {
    const userId = Number(req.params.userId);
    if (isNaN(userId)) return res.status(400).json({ error: "Invalid userId" });

    // Get user's current balance from database
    const [userRows] = await pool.query(
      "SELECT balance FROM users WHERE id = ?",
      [userId]
    );
    const userBalance = userRows[0]?.balance || 0;

    // Fetch all expenses involving this user — sorted newest first
    const [expenses] = await pool.query(
      `SELECT e.*, u.name AS payer_name 
       FROM expenses e
       JOIN users u ON e.paid_by = u.id
       WHERE e.user_id = ? OR e.paid_by = ? OR JSON_CONTAINS(e.split_with, CAST(? AS JSON))
       ORDER BY e.date DESC, e.created_at DESC`,
      [userId, userId, JSON.stringify(userId)]
    );

    // Calculate owed and owes from unpaid expenses
    let tempOwed = 0;
    let tempOwes = 0;

    const processedExpenses = expenses.map(exp => {
      let splitWith = [];
      try {
        splitWith = Array.isArray(exp.split_with)
          ? exp.split_with
          : JSON.parse(exp.split_with || "[]");
      } catch {
        splitWith = [];
      }

      const share = splitWith.length > 0 ? exp.amount / splitWith.length : exp.amount;

      if (!exp.paid) {
        if (exp.paid_by === userId) {
          const othersCount = splitWith.filter(id => Number(id) !== userId).length;
          tempOwed += share * othersCount;
        } else if (splitWith.includes(userId) || splitWith.includes(String(userId))) {
          tempOwes += share;
        }
      }

      return {
        ...exp,
        category: exp.category || "other",
        split_with: splitWith
      };
    });

    const recentExpenses = [...processedExpenses].slice(0, 3);

    res.json({
      expenses: processedExpenses,
      recentExpenses,
      owed: tempOwed,
      owes: tempOwes,
      balance: userBalance
    });
  } catch (err) {
    console.error("FETCH EXPENSES ERR", err);
    res.status(500).json({ error: "Server error: " + err.message });
  }
});

// Mark expense as paid
app.post("/api/expenses/paid/:expenseId", async (req, res) => {
  console.log("=== MARK PAID REQUEST RECEIVED ===");
  console.log("Expense ID from URL:", req.params.expenseId);

  const conn = await pool.getConnection();

  try {
    const expenseId = req.params.expenseId;

    if (!expenseId) {
      console.log("ERROR: No expenseId provided");
      return res.status(400).json({ error: "expenseId required" });
    }

    console.log(`Processing mark paid for expense ID: ${expenseId}`);

    await conn.beginTransaction();

    // Fetch expense details
    const [expenseRows] = await conn.query(
      "SELECT * FROM expenses WHERE id = ?",
      [expenseId]
    );

    if (!expenseRows.length) {
      await conn.rollback();
      conn.release();
      return res.status(404).json({ error: "Expense not found" });
    }

    const expense = expenseRows[0];

    // Check if already paid
    if (expense.paid) {
      await conn.rollback();
      conn.release();
      return res.status(400).json({ error: "Expense already marked as paid" });
    }

    // Parse split_with
    let splitWith = [];
    try {
      splitWith = typeof expense.split_with === 'string'
        ? JSON.parse(expense.split_with)
        : expense.split_with;

      if (!Array.isArray(splitWith)) {
        splitWith = [];
      }
    } catch (parseErr) {
      console.error("Error parsing split_with:", parseErr);
      await conn.rollback();
      conn.release();
      return res.status(500).json({ error: "Invalid split_with data" });
    }

    if (splitWith.length === 0) {
      await conn.rollback();
      conn.release();
      return res.status(400).json({ error: "No users to split expense with" });
    }

    const payerId = Number(expense.paid_by);
    const totalAmount = Number(expense.amount);
    const shareAmount = totalAmount / splitWith.length;

    console.log("Processing payment:", {
      expenseId,
      payerId,
      totalAmount,
      splitWith,
      shareAmount
    });

    // Update balances for each person in the split
    for (let userId of splitWith) {
      const uid = Number(userId);

      // Verify user exists
      const [userRows] = await conn.query(
        "SELECT id FROM users WHERE id = ?",
        [uid]
      );

      if (!userRows.length) {
        await conn.rollback();
        conn.release();
        return res.status(404).json({ error: `User ${uid} not found` });
      }

      if (uid === payerId) {
        // Payer gets credited for shares others owe them
        const amountOwed = shareAmount * (splitWith.length - 1);
        await conn.query(
          "UPDATE users SET balance = COALESCE(balance, 0) + ? WHERE id = ?",
          [amountOwed, uid]
        );
        console.log(`Payer ${uid} is owed ${amountOwed}`);
      } else {
        // Non-payers owe their share to the payer
        await conn.query(
          "UPDATE users SET balance = COALESCE(balance, 0) - ? WHERE id = ?",
          [shareAmount, uid]
        );
        console.log(`User ${uid} owes ${shareAmount}`);
      }
    }

    // Mark expense as paid
    await conn.query(
      "UPDATE expenses SET paid = 1 WHERE id = ?",
      [expenseId]
    );

    console.log(`✅ Expense ${expenseId} marked as paid`);

    await conn.commit();
    conn.release();

    return res.json({
      message: "Expense marked as paid successfully",
      details: {
        shareAmount,
        totalParticipants: splitWith.length
      }
    });

  } catch (err) {
    console.error("MARK PAID ERROR:", err);

    try {
      await conn.rollback();
    } catch (rollbackErr) {
      console.error("Rollback error:", rollbackErr);
    }

    conn.release();
    return res.status(500).json({ error: "Server error: " + err.message });
  }
});

// ============================================
// AI RECOMMENDATIONS
// ============================================

app.get("/api/recommendations", (req, res) => {
  try {
    const filePath = path.join(__dirname, "www", "recommendations.json");
    if (fs.existsSync(filePath)) {
      const data = fs.readFileSync(filePath, "utf8");
      const parsed = JSON.parse(data);
      res.json(parsed);
    } else {
      res.status(404).json({ message: "No recommendations found yet" });
    }
  } catch (err) {
    console.error("Error reading recommendations:", err);
    res.status(500).json({ error: "Failed to load AI recommendations" });
  }
});

// ============================================
// CALENDAR EVENTS
// ============================================

// Add calendar event
// ➕ Add new calendar event
app.post("/api/calendar/add", async (req, res) => {
  try {
    const { user_id, event_name, due_date, reminder_type } = req.body;

    if (!user_id || !event_name || !due_date) {
      return res.status(400).json({ error: "Missing required fields" });
    }

    const [result] = await pool.query(
      `INSERT INTO calendar (user_id, event_name, due_date, reminder_type)
       VALUES (?, ?, ?, ?)`,
      [user_id, event_name, due_date, reminder_type || "none"]
    );

    res.json({
      success: true,
      event: {
        id: result.insertId,
        user_id,
        event_name,
        due_date,
        reminder_type,
      },
    });
  } catch (error) {
    console.error("❌ Error adding event:", error);
    res.status(500).json({ error: "Failed to add event" });
  }
});



// Fetch user events
// 📅 Fetch all events for a specific user
// 📅 Fetch all events for a specific user
app.get("/api/calendar/:userId", async (req, res) => {
  try {
    const userId = req.params.userId;

    const [events] = await pool.query(
      `SELECT id, user_id, event_name, due_date, reminder_type 
       FROM calendar 
       WHERE user_id = ? 
       ORDER BY due_date ASC`,
      [userId]
    );

    res.json(events);
  } catch (error) {
    console.error("❌ Error fetching events:", error);
    res.status(500).json({ error: "Failed to fetch events" });
  }
});



// Delete calendar event
app.delete("/api/calendar/delete/:eventId", async (req, res) => {
  try {
    const { eventId } = req.params;

    await pool.query("DELETE FROM calendar_events WHERE id = ?", [eventId]);
    
    res.json({ message: "Event deleted successfully!" });
  } catch (error) {
    console.error("Error deleting event:", error);
    res.status(500).json({ message: "Error deleting event" });
  }
});



// ============================================
// START SERVER
// ============================================

app.listen(PORT, () => {
  console.log("\n" + "=".repeat(60));
  console.log("🚀 SERVER STARTED SUCCESSFULLY");
  console.log("=".repeat(60));
  console.log(`✅ Server running on port ${PORT}`);
  console.log(`📊 Charts directory: ${path.resolve("./www")}`);
  console.log(`🔍 Request logging: ENABLED`);
  console.log(`📁 Working directory: ${__dirname}`);
  console.log("\n🧪 Debug endpoints available:");
  console.log(`   - GET  http://localhost:${PORT}/api/debug/check-files`);
  console.log(`   - POST http://localhost:${PORT}/api/debug/trigger-r/:userId`);
  console.log(`   - GET  http://localhost:${PORT}/api/debug/test-flow/:userId`);
  console.log(`   - POST http://localhost:${PORT}/api/debug/test-add-expense`);
  console.log("\n🎯 Quick tests:");
  console.log(`   # Check srouter.postystem status`);
  console.log(`   curl http://localhost:${PORT}/api/debug/check-files`);
  console.log(`\n   # Test R script trigger`);
  console.log(`   curl -X POST http://localhost:${PORT}/api/debug/trigger-r/1`);
  console.log(`\n   # Test add expense + R script`);
  console.log(`   curl -X POST http://localhost:${PORT}/api/debug/test-add-expense -H "Content-Type: application/json" -d '{"userId":1}'`);
  console.log("=".repeat(60) + "\n");
});