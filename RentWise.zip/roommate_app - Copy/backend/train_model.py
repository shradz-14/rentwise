import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.linear_model import LogisticRegression
import pickle

# ---------------- Dummy Dataset ----------------
data = {
    "sleep_schedule": ["Early", "Late", "Flexible", "Late", "Early", "Flexible", "Late", "Early", "Early", "Late"],
    "cleanliness": ["High", "Low", "Medium", "High", "Low", "Medium", "High", "Low", "Medium", "High"],
    "smoking": ["No", "Yes", "No", "No", "Yes", "No", "Yes", "No", "Yes", "No"],
    "alcohol": ["No", "Yes", "Yes", "No", "Yes", "No", "No", "Yes", "No", "Yes"],
    "guests_allowed": ["Yes", "No", "Yes", "Yes", "No", "Yes", "No", "Yes", "No", "Yes"],
    "social_style": ["Introvert", "Extrovert", "Balanced", "Extrovert", "Introvert", "Balanced", "Introvert", "Extrovert", "Balanced", "Introvert"],
    "sharing_items": ["Yes", "No", "Yes", "No", "Yes", "Yes", "No", "Yes", "No", "Yes"],
    "talkativeness": ["Low", "High", "Medium", "High", "Low", "Medium", "Low", "High", "Medium", "Low"],
    "work_schedule": ["9-5", "Night", "Flexible", "9-5", "Night", "Flexible", "9-5", "Night", "Flexible", "9-5"],
    "quiet_hours": ["Yes", "No", "Yes", "Yes", "No", "Yes", "No", "Yes", "Yes", "No"],
    "budget_range": ["Low", "High", "Medium", "Medium", "Low", "High", "Medium", "Low", "High", "Medium"],
    "location": ["City", "Suburb", "City", "Suburb", "City", "Suburb", "City", "Suburb", "City", "Suburb"],
    "compatibility": [1, 0, 1, 0, 1, 1, 0, 1, 0, 1]   # 1 = Compatible, 0 = Not Compatible
}

df = pd.DataFrame(data)

# ---------------- Encode Categorical Columns ----------------
encoders = {}
for column in df.columns:
    if df[column].dtype == 'object':
        le = LabelEncoder()
        df[column] = le.fit_transform(df[column])
        encoders[column] = le

# ---------------- Train Model ----------------
X = df.drop("compatibility", axis=1)
y = df["compatibility"]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

model = LogisticRegression()
model.fit(X_train, y_train)

print("✅ Model trained. Accuracy:", model.score(X_test, y_test))

# ---------------- Save Model ----------------
pickle.dump({"model": model, "encoders": encoders}, open("backend/compatibility_model.pkl", "wb"))
print("✅ Model saved as backend/compatibility_model.pkl")
