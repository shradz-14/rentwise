import pandas as pd
import numpy as np
import mysql.connector
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import IsolationForest
from sklearn.cluster import KMeans
from datetime import datetime
import json

# ------------------------- CONFIG -------------------------
DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "shraddha-1401",
    "database": "roommate_app"
}

# ------------------------- CONNECT DB -------------------------
try:
    conn = mysql.connector.connect(**DB_CONFIG)
    query = "SELECT id, description, amount, category, date FROM expenses WHERE paid = 1"
    df = pd.read_sql(query, conn)
    conn.close()
except Exception as e:
    print("Database connection error:", e)
    exit()

if df.empty:
    print(json.dumps({"error": "No expenses found"}))
    exit()

# ------------------------- CLEAN DATA -------------------------
df["date"] = pd.to_datetime(df["date"])
df["month"] = df["date"].dt.to_period("M").astype(str)
monthly_expense = df.groupby(["month", "category"])["amount"].sum().reset_index()

# ------------------------- 1️⃣ PREDICTIVE AI -------------------------
predictions = {}
recommendations = []

if not monthly_expense.empty:
    for cat in monthly_expense["category"].unique():
        cat_data = monthly_expense[monthly_expense["category"] == cat]
        if len(cat_data) >= 2:  # Need at least 2 data points
            cat_data["month_num"] = range(len(cat_data))
            X = cat_data[["month_num"]]
            y = cat_data["amount"]
            model = LinearRegression()
            model.fit(X, y)
            next_month = np.array([[len(cat_data)]])
            predicted = model.predict(next_month)[0]
            predictions[cat] = round(predicted, 2)
        else:
            predictions[cat] = round(cat_data["amount"].iloc[-1], 2)

# ------------------------- 2️⃣ BEHAVIORAL CLUSTERING (K-MEANS) -------------------------
# Total spent per category
cat_totals = df.groupby("category")["amount"].sum()
cat_df = pd.DataFrame(cat_totals).reset_index()

if len(cat_df) >= 3:
    X = cat_df[["amount"]]
    kmeans = KMeans(n_clusters=3, n_init=10, random_state=42)
    cat_df["cluster"] = kmeans.fit_predict(X)

    cluster_names = ["Essential Spender", "Balanced Spender", "Luxury Leaner"]
    avg_spend = cat_df.groupby("cluster")["amount"].mean()
    cluster_order = avg_spend.sort_values().index
    cluster_mapping = {i: cluster_names[idx] for idx, i in enumerate(cluster_order)}
    cat_df["type"] = cat_df["cluster"].map(cluster_mapping)

    dominant_type = cat_df.loc[cat_df["amount"].idxmax(), "type"]
else:
    dominant_type = "Balanced Spender"

# ------------------------- 3️⃣ ANOMALY DETECTION -------------------------
iso = IsolationForest(contamination=0.15, random_state=42)
df["amount_log"] = np.log1p(df["amount"])
df["anomaly"] = iso.fit_predict(df[["amount_log"]])
anomalies = df[df["anomaly"] == -1]

# ------------------------- 4️⃣ BUILD SMART RECOMMENDATIONS -------------------------
total_spent = df["amount"].sum()
avg_spend = df.groupby("month")["amount"].sum().mean()

# Trend analysis
if total_spent > avg_spend * 1.2:
    recommendations.append("Your spending is rising sharply — consider reviewing your budget for essentials.")
elif total_spent < avg_spend * 0.8:
    recommendations.append("You’re saving well this month! Try maintaining this momentum.")

# Behavior type
recommendations.append(f"Your spending style is classified as **{dominant_type}** based on recent patterns.")

# Category predictions
for cat, pred in predictions.items():
    recommendations.append(f"Expected spending next month for **{cat}**: ₹{pred}")

# Anomalies
if not anomalies.empty:
    sample_anom = anomalies.sample(min(3, len(anomalies)))
    for _, row in sample_anom.iterrows():
        recommendations.append(
            f"Unusual expense detected: ₹{row['amount']} on {row['category']} ({row['description'][:30]}...)"
        )

# ------------------------- 5️⃣ EXPORT OUTPUT -------------------------
output = {
    "total_spent": round(total_spent, 2),
    "predictions": predictions,
    "spending_type": dominant_type,
    "recommendations": recommendations
}

with open("./www/recommendations.json", "w") as f:
    json.dump(output, f, indent=2)

print(json.dumps(output, indent=2))
