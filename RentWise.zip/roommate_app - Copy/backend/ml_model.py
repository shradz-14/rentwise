import sys, json
from sklearn.preprocessing import LabelEncoder

# Read data from Node.js
data = json.loads(sys.stdin.read())

current = data["currentPrefs"]
target = data["targetPrefs"]

# Define all categorical fields (match frontend)
categorical_fields = [
    "sleep_schedule", "smoking", "alcohol", "guests_allowed",
    "social_style", "sharing_items", "talkativeness",
    "work_schedule", "quiet_hours", "budget_range", "location"
]

numeric_fields = ["cleanliness"]

# --- Encode categorical values consistently ---
def normalize(value):
    if isinstance(value, str):
        return value.strip().lower()
    return value

# --- Compute Compatibility ---
score = 0
total = 0

for key in current:
    if key in ["id", "user_id", None]:
        continue

    val1 = normalize(current.get(key))
    val2 = normalize(target.get(key))

    if val1 is None or val2 is None:
        continue

    total += 1
    if key in numeric_fields:
        try:
            diff = abs(float(val1) - float(val2))
            score += max(0, 1 - diff / 10)  # normalize numeric difference
        except:
            continue
    else:
        score += 1 if val1 == val2 else 0

final_score = int((score / total) * 100) if total > 0 else 0
print(final_score)
