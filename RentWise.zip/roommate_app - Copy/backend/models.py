from sqlalchemy import Column, Integer, String, Float, Date, ForeignKey
from sqlalchemy.orm import relationship
from .database import Base

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100))
    email = Column(String(100), unique=True, index=True)
    password = Column(String(100))
   
class Preferences(Base):
    __tablename__ = "preferences"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    sleep_schedule = Column(String(50), default="Flexible")
    cleanliness = Column(String(50), default="Medium")
    smoking = Column(String(50), default="No")
    alcohol = Column(String(50), default="No")
    guests_allowed = Column(String(50), default="Sometimes")
    social_style = Column(String(50), default="Balanced")
    sharing_items = Column(String(50), default="Sometimes")
    talkativeness = Column(String(50), default="Medium")
    work_schedule = Column(String(50), default="Flexible")
    quiet_hours = Column(String(50), default="None")
    budget_range = Column(String(50), default="Medium")
    location = Column(String(100), default="Any")
    user = relationship("User", back_populates="preferences")

class Expense(Base):
    __tablename__ = "expenses"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    description = Column(String(200))
    amount = Column(Float)
    category = Column(String(50))
    date = Column(Date)
    user = relationship("User", back_populates="expenses")

class CalendarEvent(Base):
    __tablename__ = "calendar_events"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    event_name = Column(String(100))
    due_date = Column(Date)
    reminder_type = Column(String(50))
    user = relationship("User", back_populates="calendar_events")

# Add relationships to User
User.preferences = relationship("Preferences", back_populates="user", uselist=False)
User.expenses = relationship("Expense", back_populates="user")
User.calendar_events = relationship("CalendarEvent", back_populates="user")
