# backend/train_ai_expense.py
import pickle
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB

# Dummy data
descriptions = [
    "Bought pizza and soda", 
    "Uber ride to office", 
    "Electricity bill", 
    "Netflix subscription", 
    "Lunch at cafe", 
    "Bus ticket", 
    "Water bill"
]

categories = ["Food", "Transport", "Utilities", "Entertainment", "Food", "Transport", "Utilities"]

# Vectorize text
vectorizer = CountVectorizer()
X = vectorizer.fit_transform(descriptions)

# Train model
model = MultinomialNB()
model.fit(X, categories)

# Save model + vectorizer
pickle.dump({"model": model, "vectorizer": vectorizer}, open("backend/ai_expense.pkl", "wb"))
print("AI Expense model saved as ai_expense.pkl")
