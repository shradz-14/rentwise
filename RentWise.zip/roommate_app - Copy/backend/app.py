# backend/app.py
import os
import logging
from typing import Optional, List, Dict, Any

from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
import pandas as pd
import pickle
import numpy as np

# DB imports (ensure backend.database exists and is configured)
from backend.database import SessionLocal, engine  # SQLAlchemy engine, SessionLocal
from backend import models  # ensure models module is imported so classes are registered
from backend.models import User, Preferences, Expense, CalendarEvent  # ORM classes
from sqlalchemy.orm import Session

# Create all tables (safe for development)
models.Base.metadata.create_all(bind=engine)

log = logging.getLogger("uvicorn.error")

app = FastAPI(title="Roommate & Expense App")

# Allow CORS for local frontend while developing
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://127.0.0.1:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# -------------------------
# Load ML models (compatibility + expense)
# -------------------------
BACKEND_DIR = os.path.dirname(__file__)

compat_model = None
compat_encoders: Dict[str, Any] = {}
compat_model_path = os.path.join(BACKEND_DIR, "compatibility_model.pkl")
if os.path.exists(compat_model_path):
    try:
        bundle = pickle.load(open(compat_model_path, "rb"))
        compat_model = bundle.get("model")
        compat_encoders = bundle.get("encoders", {})
        log.info("Loaded compatibility_model from %s", compat_model_path)
    except Exception as e:
        log.exception("Failed to load compatibility_model.pkl: %s", e)
        compat_model = None
else:
    log.warning("compatibility_model.pkl not found at %s. Run backend/train_model.py to create it.", compat_model_path)

expense_model = None
expense_vectorizer = None
expense_model_path = os.path.join(BACKEND_DIR, "ai_expense.pkl")
if os.path.exists(expense_model_path):
    try:
        bundle = pickle.load(open(expense_model_path, "rb"))
        expense_model = bundle.get("model")
        expense_vectorizer = bundle.get("vectorizer")
        log.info("Loaded expense AI model from %s", expense_model_path)
    except Exception as e:
        log.exception("Failed to load ai_expense.pkl: %s", e)
        expense_model = None
else:
    log.info("ai_expense.pkl not found, expense auto-categorization disabled.")


# -------------------------
# DB Dependency
# -------------------------
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# -------------------------
# Pydantic request/response models
# -------------------------
class UserCreate(BaseModel):
    name: str
    email: str
    password: str
    bio: Optional[str] = None
    profile_photo: Optional[str] = None


class LoginData(BaseModel):
    email: str
    password: str


class PreferencesIn(BaseModel):
    user_id: int
    sleep_schedule: str
    cleanliness: str
    smoking: str
    alcohol: str
    guests_allowed: str
    social_style: str
    sharing_items: str
    talkativeness: str
    work_schedule: str
    quiet_hours: str
    budget_range: str
    location: str


class CompatibilityRequest(BaseModel):
    sleep_schedule: str
    cleanliness: str
    smoking: str
    alcohol: str
    guests_allowed: str
    social_style: str
    sharing_items: str
    talkativeness: str
    work_schedule: str
    quiet_hours: str
    budget_range: str
    location: str


class CompatibilityWithUserRequest(BaseModel):
    source_preferences: CompatibilityRequest
    target_email: str


class ExpenseIn(BaseModel):
    user_id: int
    description: str
    amount: float


class CalendarIn(BaseModel):
    user_id: int
    event_name: str
    due_date: str  # YYYY-MM-DD
    reminder_type: Optional[str] = "app"


# -------------------------
# Helper functions for ML / encoding
# -------------------------
def _encode_single_row(encoders: Dict[str, Any], row: Dict[str, Any]) -> pd.DataFrame:
    """
    Encode a single preference dict into a DataFrame acceptable by the model.
    If encoder doesn't have the incoming class, map to the encoder's most common class (index 0).
    """
    df = pd.DataFrame([row])
    for col in df.columns:
        if col not in encoders:
            raise ValueError(f"No encoder found for column '{col}'. Model encoders missing.")
        le = encoders[col]
        val = df.at[0, col]
        try:
            # transform expects array-like
            df[col] = le.transform([val])
        except Exception:
            # unseen label -> fallback to most frequent/first class
            fallback = le.classes_[0]
            df[col] = le.transform([fallback])
    return df


def predict_prob_from_preferences(pref: Dict[str, Any]) -> float:
    """
    Return probability of compatibility=1 for a single preference dict.
    Requires compat_model and compat_encoders to be loaded.
    """
    if compat_model is None or not compat_encoders:
        raise RuntimeError("Compatibility model not loaded. Run training script (backend/train_model.py).")
    df_encoded = _encode_single_row(compat_encoders, pref)
    proba = compat_model.predict_proba(df_encoded)[0][1]
    return float(proba)


def make_text_report(source: Dict[str, Any], target: Dict[str, Any]) -> Dict[str, Any]:
    """
    Produce a simple match breakdown between two pref dicts.
    Returns number of matches, total fields, and per-field match info.
    """
    fields = list(source.keys())
    matches = []
    mismatches = []
    for f in fields:
        s_val = str(source[f]).lower()
        t_val = str(target.get(f, "")).lower()
        if s_val == t_val:
            matches.append(f)
        else:
            mismatches.append({"field": f, "source": source[f], "target": target.get(f)})
    match_percent = int(len(matches) / max(1, len(fields)) * 100)
    return {"matches": matches, "mismatches": mismatches, "match_percent": match_percent}


# -------------------------
# USERS endpoints
# -------------------------
@app.post("/register")
def register_user(payload: UserCreate, db: Session = Depends(get_db)):
    # simple uniqueness check by email
    existing = db.query(User).filter(User.email == payload.email).first()
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")
    user = User(
        name=payload.name,
        email=payload.email,
        password=payload.password,  # NOTE: store hashed in production
        bio=payload.bio,
        profile_photo=payload.profile_photo,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return {"message": "User registered", "id": user.id}


@app.post("/login")
def login(payload: LoginData, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == payload.email).first()
    if not user or user.password != payload.password:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    # return basic user info (no password)
    return {"message": "Login successful", "user": {"id": user.id, "name": user.name, "email": user.email}}


@app.get("/users", response_model=List[Dict[str, Any]])
def list_users(db: Session = Depends(get_db)):
    users = db.query(User).all()
    out = []
    for u in users:
        out.append({
            "id": u.id,
            "name": u.name,
            "email": u.email,
            "bio": u.bio,
            "profile_photo": u.profile_photo
        })
    return out


# -------------------------
# PREFERENCES endpoints (create/update)
# -------------------------
@app.post("/preferences")
def set_preferences(payload: PreferencesIn, db: Session = Depends(get_db)):
    # Upsert: replace or create
    pref = db.query(Preferences).filter(Preferences.user_id == payload.user_id).first()
    if pref:
        # update
        for k, v in payload.dict(exclude={"user_id"}).items():
            setattr(pref, k, v)
    else:
        pref = Preferences(**payload.dict())
        db.add(pref)
    db.commit()
    db.refresh(pref)
    return {"message": "Preferences saved", "preferences_id": pref.id}


# -------------------------
# COMPATIBILITY endpoints
# -------------------------
@app.post("/compatibility", summary="Predict compatibility for a single preference object")
def compatibility(payload: CompatibilityRequest):
    """
    Accepts a single user's preferences and returns model probability and a short textual verdict.
    """
    if compat_model is None:
        raise HTTPException(status_code=500, detail="Compatibility model not loaded. Run backend/train_model.py")

    # convert to dict (strings)
    pref = payload.dict()
    try:
        prob = predict_prob_from_preferences(pref)
    except Exception as e:
        log.exception("Error predicting compatibility: %s", e)
        raise HTTPException(status_code=500, detail="Error during compatibility prediction: " + str(e))

    percent = int(prob * 100)
    verdict = "Low Match ❌"
    if percent > 70:
        verdict = "Great Match ✅"
    elif percent > 40:
        verdict = "Moderate Match ⚠️"

    return {
        "compatibility_probability": round(prob, 4),
        "compatibility_percent": f"{percent}%",
        "verdict": verdict
    }


@app.post("/compatibility_with_user", summary="Compare a source pref object with a target user stored in DB")
def compatibility_with_user(payload: CompatibilityWithUserRequest, db: Session = Depends(get_db)):
    if compat_model is None:
        raise HTTPException(status_code=500, detail="Compatibility model not loaded. Run backend/train_model.py")

    # find target user by email and their preferences
    target_user = db.query(User).filter(User.email == payload.target_email).first()
    if not target_user:
        raise HTTPException(status_code=404, detail="Target user not found")

    target_pref = db.query(Preferences).filter(Preferences.user_id == target_user.id).first()
    if not target_pref:
        raise HTTPException(status_code=404, detail="Target user has no saved preferences")

    # convert ORM prefs to dict of strings
    pref_fields = [
        "sleep_schedule","cleanliness","smoking","alcohol","guests_allowed",
        "social_style","sharing_items","talkativeness","work_schedule",
        "quiet_hours","budget_range","location"
    ]
    target_pref_dict = {f: getattr(target_pref, f) for f in pref_fields}
    source_pref_dict = payload.source_preferences.dict()

    # per-field textual matching
    breakdown = make_text_report(source_pref_dict, target_pref_dict)

    # Predict probability for source and target individually, then average
    try:
        p_source = predict_prob_from_preferences(source_pref_dict)
        p_target = predict_prob_from_preferences(target_pref_dict)
    except Exception as e:
        log.exception("Error predicting compatibility: %s", e)
        raise HTTPException(status_code=500, detail="Error during compatibility prediction: " + str(e))

    final_prob = float((p_source + p_target) / 2.0)
    percent = int(final_prob * 100)
    verdict = "Low Match ❌"
    if percent > 70:
        verdict = "Great Match ✅"
    elif percent > 40:
        verdict = "Moderate Match ⚠️"

    # Small textual report combining model and breakdown
    report = [
        f"Model-based compatibility: {percent}%",
        f"Field-wise match: {breakdown['match_percent']}% matched",
    ]
    # include up to 3 specifics
    if breakdown["mismatches"]:
        report.append(f"Mismatched fields: {[m['field'] for m in breakdown['mismatches']][:5]}")

    return {
        "target_user": {"id": target_user.id, "email": target_user.email, "name": target_user.name},
        "compatibility_probability": round(final_prob, 4),
        "compatibility_percent": f"{percent}%",
        "verdict": verdict,
        "breakdown": breakdown,
        "report": report
    }


# -------------------------
# EXPENSES endpoints
# -------------------------
@app.post("/expenses")
def add_expense(payload: ExpenseIn, db: Session = Depends(get_db)):
    category = "Uncategorized"
    if expense_model is not None and expense_vectorizer is not None:
        try:
            X = expense_vectorizer.transform([payload.description])
            category = expense_model.predict(X)[0]
        except Exception:
            category = "Uncategorized"

    exp = Expense(
        user_id=payload.user_id,
        description=payload.description,
        amount=payload.amount,
        category=category,
    )
    db.add(exp)
    db.commit()
    db.refresh(exp)
    return {"message": "Expense added", "expense_id": exp.id, "category": category}


@app.get("/expenses")
def list_expenses(user_id: Optional[int] = None, db: Session = Depends(get_db)):
    q = db.query(Expense)
    if user_id:
        q = q.filter(Expense.user_id == user_id)
    rows = q.all()
    out = []
    for r in rows:
        out.append({
            "id": r.id,
            "user_id": r.user_id,
            "description": r.description,
            "amount": float(r.amount),
            "category": r.category,
            "date": r.date.isoformat() if r.date else None
        })
    return out


# -------------------------
# CALENDAR endpoints
# -------------------------
@app.post("/calendar")
def add_event(payload: CalendarIn, db: Session = Depends(get_db)):
    try:
        due = pd.to_datetime(payload.due_date).date()
    except Exception:
        raise HTTPException(status_code=400, detail="due_date must be YYYY-MM-DD")
    ev = CalendarEvent(
        user_id=payload.user_id,
        event_name=payload.event_name,
        due_date=due,
        reminder_type=payload.reminder_type
    )
    db.add(ev)
    db.commit()
    db.refresh(ev)
    return {"message": "Event added", "event_id": ev.id}


@app.get("/calendar")
def list_events(user_id: Optional[int] = None, db: Session = Depends(get_db)):
    q = db.query(CalendarEvent)
    if user_id:
        q = q.filter(CalendarEvent.user_id == user_id)
    rows = q.all()
    return [{"id": r.id, "user_id": r.user_id, "event_name": r.event_name, "due_date": r.due_date.isoformat(), "reminder_type": r.reminder_type} for r in rows]


# -------------------------
# Root / health
# -------------------------
@app.get("/")
def root():
    status = {
        "backend": "ok",
        "compatibility_model": bool(compat_model),
        "expense_ai": bool(expense_model)
    }
    return status
